package com.nycschools.presentation.viewmodel

import com.nycschools.domain.model.School
import com.nycschools.domain.usecase.GetSchoolsUseCase
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SchoolListViewModelTest {

    private val dummySchools = listOf(
        School(dbn = "01M292", name = "H.S. Example", borough = "Manhattan", overview = "", phone = "", website = "", city = "", zip = ""),
        School(dbn = "02M123", name = "Another School", borough = "Brooklyn", overview = "", phone = "", website = "", city = "", zip = "")
    )

    @Test
    fun `viewmodel emits school list on success`() = runTest {
        val useCase = mockk<GetSchoolsUseCase>()
        coEvery { useCase.invoke() } returns flow { emit(dummySchools) }

        val vm = SchoolListViewModel(useCase)

        val state = vm.uiState.value
        assertEquals(2, state.size)
        assertEquals("H.S. Example", state[0].name)
    }

    @Test
    fun `viewmodel emits empty list when no schools`() = runTest {
        val useCase = mockk<GetSchoolsUseCase>()
        coEvery { useCase.invoke() } returns flow { emit(emptyList()) }

        val vm = SchoolListViewModel(useCase)

        val state = vm.uiState.value
        assertEquals(0, state.size)
    }

    @Test
    fun `viewmodel handles exception gracefully`() = runTest {
        val useCase = mockk<GetSchoolsUseCase>()
        coEvery { useCase.invoke() } throws Exception("Network error")

        val vm = SchoolListViewModel(useCase)

        val state = vm.uiState.value
        assertEquals(0, state.size) // Assuming ViewModel returns empty list on error
    }
}
