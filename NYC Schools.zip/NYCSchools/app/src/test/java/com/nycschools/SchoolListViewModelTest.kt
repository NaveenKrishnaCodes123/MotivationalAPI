package com.nycschools

import app.cash.turbine.test
import com.nycschools.data.model.School
import com.nycschools.domain.usecase.GetSchoolsUseCase
import com.nycschools.presentation.viewmodel.SchoolListViewModel
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test
import kotlin.collections.get
import kotlin.test.assertEquals

@OptIn(ExperimentalCoroutinesApi::class)
class SchoolListViewModelTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var viewModel: SchoolListViewModel
    private val getSchoolsUseCase = mockk<GetSchoolsUseCase>()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `uiState emits list of schools`() = runTest {
        val fakeSchools = listOf(
            School("1", "School A", "Bronx", null, null, null, null, null),
            School("2", "School B", "Brooklyn", null, null, null, null, null)
        )

        coEvery { getSchoolsUseCase.invoke() } returns flow { emit(fakeSchools) }

        viewModel = SchoolListViewModel(getSchoolsUseCase)

        viewModel.uiState.test {
            val emitted = awaitItem()
            assertEquals(2, emitted.size)
            assertEquals("School A", emitted[0].name)
            cancelAndIgnoreRemainingEvents()
        }
    }
}
