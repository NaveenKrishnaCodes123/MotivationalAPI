package com.mindcoin.valetparking.Model

class VehicleDetailsByHookNumberRequest (
    val companyId:String,
    val vehicleNo: String,
    val hookNo: String
)