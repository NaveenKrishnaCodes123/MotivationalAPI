package com.mindcoin.valetparking.Model

class CheckOutRequest (
    val checkInId: String,
    val checkOutTime: String
)