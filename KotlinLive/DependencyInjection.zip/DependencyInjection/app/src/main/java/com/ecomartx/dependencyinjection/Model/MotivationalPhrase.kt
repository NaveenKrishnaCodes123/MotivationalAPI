package com.ecomartx.dependencyinjection.Model

data class MotivationalPhrase(
    val id: Int,
    val phrase: String,
    val author: String,
    val religion: Int
)