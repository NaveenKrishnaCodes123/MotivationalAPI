package com.unik.ecomartx

import androidx.lifecycle.ViewModelProvider
import com.unik.ecomartx.repository.AuthRepository
import com.unik.ecomartx.viewModel.ViewModel

class GetUserDetailsModelFactory(private val repository: AuthRepository) : ViewModelProvider.Factory {
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        return ViewModel.getUserViewModel(repository) as T
    }
}
class GetMobileCategories(private val repository: AuthRepository) : ViewModelProvider.Factory {
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        return ViewModel.getMobileCategories(repository) as T
    }
}

class GetCartItemsList(private val repository: AuthRepository) : ViewModelProvider.Factory {
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        return ViewModel.getListOfCartItems(repository) as T
    }
}