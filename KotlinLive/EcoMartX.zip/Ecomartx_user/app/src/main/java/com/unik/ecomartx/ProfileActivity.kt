package com.unik.ecomartx

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ProfileActivity : AppCompatActivity() {

    lateinit var ivBack : ImageView
    private lateinit var  profile: LinearLayout
    private lateinit var  goldMembership: TextView
    private lateinit var  viewActivity: TextView
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        sharedPreferencesHelper = SharedPreferencesHelper(this)
        val loginResponse = sharedPreferencesHelper.getLoginResponse()
        ivBack = findViewById(R.id.ivBack)
        profile = findViewById(R.id.profile)
        goldMembership = findViewById(R.id.goldMembership)
        viewActivity = findViewById(R.id.viewActivity)
        val logout: LinearLayout= findViewById(R.id.btnLogout)

        ivBack.setOnClickListener {
            finish()
        }
        profile.setOnClickListener {
            val intent = Intent(this, YourProfileActivity::class.java)
            startActivity(intent)
        }
        viewActivity.setOnClickListener {
            val intent = Intent(this, YourProfileActivity::class.java)
            startActivity(intent)
        }
        goldMembership.setOnClickListener {
            val intent = Intent(this, EcoPremium::class.java)
            startActivity(intent)
        }
        logout.setOnClickListener {
                showLogoutDialog()
        }

    }

    private fun showLogoutDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Logout")
        builder.setMessage("Do you want to logout?")
        builder.setPositiveButton("Yes") { dialog, which ->
            sharedPreferencesHelper.clearLoginData()
           finish()
        }
        builder.setNegativeButton("No") { dialog, which ->
            dialog.dismiss()
        }

        // Show the AlertDialog
        builder.show()
    }
}