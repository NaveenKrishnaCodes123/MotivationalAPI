package com.unik.ecomartx.viewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindcoin.dservicevp.apis.ApiService
import com.unik.ecomartx.ApiResult
import com.unik.ecomartx.Resource
import com.unik.ecomartx.model.Categories
import com.unik.ecomartx.model.MobileCategories
import com.unik.ecomartx.model.NearbyRestaurants.GetRestaurentsById
import com.unik.ecomartx.model.NearbyRestaurants.MenuItemApiResponse
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsRequest
import com.unik.ecomartx.model.NearbyRestaurants.Restaurant
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsResponse
import com.unik.ecomartx.model.addToCart.AddToCartRequest
import com.unik.ecomartx.model.addToCart.AddToCartResponse
import com.unik.ecomartx.model.addToCart.CartItem
import com.unik.ecomartx.model.address.AddAddressRequest
import com.unik.ecomartx.model.address.AddAddressResponse
import com.unik.ecomartx.model.generateOTP.GenerateOtpRequest
import com.unik.ecomartx.model.generateOTP.GenerateOtpResponse
import com.unik.ecomartx.model.getUserProfile.UserData
import com.unik.ecomartx.model.getUserProfile.UserProfileResponse
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartRequest
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartResponse
import com.unik.ecomartx.model.userRegister.userRegisterRequest
import com.unik.ecomartx.model.userRegister.userRegisterResponse
import com.unik.ecomartx.model.verifyOtp.VerifyOtpResponse
import com.unik.ecomartx.modelimport.CartItemList
import com.unik.ecomartx.modelimport.GetListOfCartItemsResponse
import com.unik.ecomartx.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewModel() : ViewModel() {
    private val _otpResponse = MutableLiveData<Resource<GenerateOtpResponse>>()
    val vehicleCheckInResponse: LiveData<Resource<GenerateOtpResponse>> get() = _otpResponse

    fun otpRequest(request: GenerateOtpRequest) {
        _otpResponse.value = Resource.Loading()

        // Make the API call
        ApiService.api.generateOtp(request).enqueue(object : Callback<GenerateOtpResponse> {
            override fun onResponse(
                call: Call<GenerateOtpResponse>,
                response: Response<GenerateOtpResponse>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    _otpResponse.value = Resource.Success(response.body()!!)
                } else {
                    _otpResponse.value = Resource.Failure("Error: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<GenerateOtpResponse>, t: Throwable) {
                _otpResponse.value = Resource.Failure("Failure: ${t.message}")
                Log.e("VehicleCheckIn", "API Call Failure: ${t.message}")
            }
        })
    }


    //Verify OTP Screen

    private val repository = AuthRepository()

    private val _otpVerificationState = MutableStateFlow<ApiResult<VerifyOtpResponse>?>(null)
    val otpVerificationState: StateFlow<ApiResult<VerifyOtpResponse>?> = _otpVerificationState

    fun verifyOtp(phone: String, otp: Int, deviceId: String) {
        _otpVerificationState.value = ApiResult.Loading
        viewModelScope.launch {
            val result = repository.verifyOtp(phone, otp, deviceId)
            _otpVerificationState.value = result
        }
    }

    fun resetOtpState() {
        _otpVerificationState.value = null
    }

    //User Register

    private val _userRegisterRequest = MutableStateFlow<ApiResult<userRegisterResponse>?>(null)
    val userRegisterRequest: StateFlow<ApiResult<userRegisterResponse>?> = _userRegisterRequest

    fun userRegister(authToken: String, request: userRegisterRequest) {
        _userRegisterRequest.value = ApiResult.Loading
        viewModelScope.launch {
            val result = repository.registerUser("token $authToken", request)
            _userRegisterRequest.value = result
        }
    }

    private val _addAddressRequest = MutableStateFlow<ApiResult<AddAddressResponse>?>(null)
    val addAddressRequest: StateFlow<ApiResult<AddAddressResponse>?> = _addAddressRequest

    fun addAddress(authToken: String, request: AddAddressRequest) {
        _addAddressRequest.value = ApiResult.Loading
        viewModelScope.launch {
            val result = repository.addAddress("token $authToken", request)
            _addAddressRequest.value = result
        }
    }

    private val _removeProductFromCart = MutableStateFlow<ApiResult<RemoveProductFromCartResponse>?>(null)
    val removeProductFromCart: StateFlow<ApiResult<RemoveProductFromCartResponse>?> = _removeProductFromCart

    fun removeProductFromCart(authToken: String, request: RemoveProductFromCartRequest) {
        _removeProductFromCart.value = ApiResult.Loading
        viewModelScope.launch {
            val result = repository.removeProductFromCart("token $authToken", request)
            _removeProductFromCart.value = result
        }
    }


    private val _getRestaurentItemsRequest = MutableStateFlow<ApiResult<MenuItemApiResponse>?>(null)
    val getRestaurentItemsRequest: StateFlow<ApiResult<MenuItemApiResponse>?> = _getRestaurentItemsRequest

    fun getRestaurentItems(authToken: String, request: GetRestaurentsById) {
        _getRestaurentItemsRequest.value = ApiResult.Loading
        viewModelScope.launch {
            val result = repository.getRestaurentItems("token $authToken", request)
            _getRestaurentItemsRequest.value = result
        }
    }


    //GetUserDetails

    class getUserViewModel(private val repository: AuthRepository) : ViewModel() {

        private val _userData = MutableLiveData<UserData>()
        val userData: LiveData<UserData> = _userData

        private val _isLoading = MutableLiveData<Boolean>()
        val isLoading: LiveData<Boolean> = _isLoading

        private val _error = MutableLiveData<String>()
        val error: LiveData<String> = _error

        fun fetchuserDetails(authToken: String) {
            _isLoading.value = true

            repository.getUserDetails(authToken)
                .enqueue(object : Callback<UserProfileResponse> {
                    override fun onResponse(
                        call: Call<UserProfileResponse>,
                        response: Response<UserProfileResponse>
                    ) {
                        _isLoading.value = false
                        if (response.isSuccessful && response.body() != null) {
                            _userData.postValue(response.body()!!.data)
                        } else {
                            _error.value = "Failed to load data."
                        }
                    }

                    override fun onFailure(call: Call<UserProfileResponse>, t: Throwable) {
                        _isLoading.value = false
                        _error.value = t.message ?: "An unknown error occurred."
                    }
                })
        }
    }
    private val _getNearByRestaurents = MutableStateFlow<ApiResult<NearByRestaurentsResponse>?>(null)
    val getNearbyRestaurants: StateFlow<ApiResult<NearByRestaurentsResponse>?> = _getNearByRestaurents

    fun getNearbyRestaurants(authToken: String, request: NearByRestaurentsRequest) {
        _getNearByRestaurents.value = ApiResult.Loading
        viewModelScope.launch {
            val result = repository.getNearbyRestaurants("token $authToken", request)
            _getNearByRestaurents.value = result
        }
    }

    private val _addToCart = MutableStateFlow<ApiResult<AddToCartResponse>?>(null)
    val addToCart: StateFlow<ApiResult<AddToCartResponse>?> = _addToCart

    fun addToCart(authToken: String, request: AddToCartRequest) {
        _addToCart.value = ApiResult.Loading
        viewModelScope.launch {
            val result = repository.addToCart("token $authToken", request)
            _addToCart.value = result
        }
    }

    class getMobileCategories(private val repository: AuthRepository) : ViewModel() {

        private val _categoriesData = MutableLiveData< List<Categories>>()
        val categories: LiveData<List<Categories>> = _categoriesData

        private val _isLoading = MutableLiveData<Boolean>()
        val isLoading: LiveData<Boolean> = _isLoading

        private val _error = MutableLiveData<String>()
        val error: LiveData<String> = _error

        fun getMobileCategories(authToken: String) {
            _isLoading.value = true

            repository.getMobileCategories(authToken)
                .enqueue(object : Callback<MobileCategories> {
                    override fun onResponse(
                        call: Call<MobileCategories>,
                        response: Response<MobileCategories>
                    ) {
                        _isLoading.value = false
                        if (response.isSuccessful && response.body() != null) {
                            _categoriesData.postValue(response.body()!!.categories)
                        } else {
                            _error.value = "Failed to load data."
                        }
                    }

                    override fun onFailure(call: Call<MobileCategories>, t: Throwable) {
                        _isLoading.value = false
                        _error.value = t.message ?: "An unknown error occurred."
                    }
                })
        }
    }
    class getListOfCartItems(private val repository: AuthRepository) : ViewModel() {

        private val _cartData = MutableLiveData<List<CartItemList>>()
        val cardData: LiveData<List<CartItemList>> = _cartData

        private val _isLoading = MutableLiveData<Boolean>()
        val isLoading: LiveData<Boolean> = _isLoading

        private val _error = MutableLiveData<String>()
        val error: LiveData<String> = _error

        fun getListOfCartItems(authToken: String) {
            _isLoading.value = true

            repository.getListOfCartItems(authToken)
                .enqueue(object : Callback<GetListOfCartItemsResponse> {
                    override fun onResponse(
                        call: Call<GetListOfCartItemsResponse>,
                        response: Response<GetListOfCartItemsResponse>
                    ) {
                        _isLoading.value = false
                        if (response.isSuccessful && response.body() != null) {
                            _cartData.postValue(response.body()!!.items)
                        } else {
                            _error.value = "Failed to load data."
                        }
                    }

                    override fun onFailure(call: Call<GetListOfCartItemsResponse>, t: Throwable) {
                        _isLoading.value = false
                        _error.value = t.message ?: "An unknown error occurred."
                    }
                })
        }
    }
}