package com.unik.ecomartx.model

class Banner (

    val name: String,
    val image: String
)