package com.unik.ecomartx.model.NearbyRestaurants

import java.util.Date

data class NearByRestaurentsResponse(
    val responseCode: Int,
    val message: String,
    val data: List<Restaurant>
)

data class Restaurant(
    val location: Location,
    val `_id`: String,
    val name: String,
    val ownerName: String,
    val phone: String,
    val email: String,
    val password: String,
    val documents: List<String>,
    val address: String,
    val isActive: Boolean,
    val status: String,
    val isDeleted: Boolean,
    val createdAt: Date,
    val updatedAt: Date,
    val `__v`: Int,
    val token: String,
    val isOpen: Boolean,
    val images: List<String>,
    val perKmPrice: Int,
    val targetDeliveryFee: Int,
    val weeklyAvailability: List<WeeklyAvailability>
)

data class Location(
    val type: String,
    val coordinates: List<Double>
)

data class WeeklyAvailability(
    val day: String,
    val startTime: String?,
    val endTime: String?,
    val isClosed: Boolean,
    val `_id`: String
)