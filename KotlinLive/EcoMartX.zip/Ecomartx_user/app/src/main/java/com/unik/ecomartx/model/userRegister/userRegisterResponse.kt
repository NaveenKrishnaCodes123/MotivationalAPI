package com.unik.ecomartx.model.userRegister

data class userRegisterResponse(
 val responseCode: Int,
 val message: String,
 val dob: String,
 val status: String,
 val isRegistered: Boolean,
 val refarralCode: String,
 val user: User
)
data class User(
    val id: String,
    val name: String,
    val phone: String,
    val location: Location
)
data class Location(
    val type: String= "Point",
    val coordinates: List<Double>
)