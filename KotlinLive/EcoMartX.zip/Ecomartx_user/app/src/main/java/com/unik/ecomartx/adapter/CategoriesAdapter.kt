package com.unik.ecomartx.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.imageview.ShapeableImageView
import com.unik.ecomartx.R
import com.unik.ecomartx.model.Categories

class CategoriesAdapter (
    private var categoriesList: List<Categories>,
    private val onItemClick: (Categories,position:Int) -> Unit
) : RecyclerView.Adapter<CategoriesAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.tvRestaurantName)
        val imageView: ShapeableImageView = itemView.findViewById(R.id.foodImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_restaurant, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val restaurant = categoriesList[position]

        holder.name.text = restaurant.name

        // Load first image if available
        restaurant.categoryImage.firstOrNull()?.let { imageUrl ->
            Glide.with(holder.itemView.context)
                .load("https://ecomartx.s3.ap-south-1.amazonaws.com/$imageUrl")
                .placeholder(R.drawable.beverages)
                .into(holder.imageView)
        }

        // Click listener
        holder.itemView.setOnClickListener {
            onItemClick(restaurant,position)
        }
    }

    override fun getItemCount() = categoriesList.size

    fun updateData(newList: List<Categories>) {
        categoriesList = newList
        notifyDataSetChanged()
    }

}