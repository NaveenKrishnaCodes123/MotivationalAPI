package com.unik.ecomartx

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.mindcoin.dservicevp.apis.ApiService
import com.mindcoin.dservicevp.apis.RetrofitClient
import com.mindcoin.dservicevp.loader.ProgressBarUtility
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import com.unik.ecomartx.model.getUserProfile.UserData
import com.unik.ecomartx.model.userRegister.userRegisterRequest
import com.unik.ecomartx.model.userRegister.userRegisterResponse
import com.unik.ecomartx.repository.AuthRepository
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.flow.collectLatest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.jvm.java

class YourProfileActivity : AppCompatActivity() {

    private val viewModel: ViewModel by viewModels()
    private lateinit var userProfileViewModel: ViewModel.getUserViewModel
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper

    private lateinit var mobileNumber: String
    private lateinit var authToken: String

    private lateinit var ivBack: ImageView
    private lateinit var nameEt: TextView
    private lateinit var emailEt: TextView
    private lateinit var phoneNumberEt: TextView
    private lateinit var dateOfBirthEt: TextView
    private lateinit var spinnerGender: Spinner
    private lateinit var btnSubmit: Button

    private var selectedGender: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_your_profile)

        sharedPreferencesHelper = SharedPreferencesHelper(this)

        val loginResponse = sharedPreferencesHelper.getLoginResponse()
        loginResponse?.let {
            val loginData = it.user
            if (loginData != null) {
                mobileNumber = loginData.phone ?: "N/A"
                authToken = loginData.token ?: "N/A"
            }
        } ?: run {
            Toast.makeText(this, "Please Logout and Login Once.", Toast.LENGTH_SHORT).show()
        }
        initializeViews()
        setupGenderSpinner()
        setupClickListeners()
        setupObservers()

        initialAPICall()
    }

    private fun initializeViews() {
        ivBack = findViewById(R.id.ivBack)
        nameEt = findViewById(R.id.name_et)
        emailEt = findViewById(R.id.email_et)
        phoneNumberEt = findViewById(R.id.phonenumber_et)
        dateOfBirthEt = findViewById(R.id.dateofbirth_et)
        spinnerGender = findViewById(R.id.spinnerGender)
        btnSubmit = findViewById(R.id.btnCheckout) // Add this button in your XML
        phoneNumberEt.setText(mobileNumber)

    }

    private fun setupGenderSpinner() {
        val genderOptions = listOf("Select Gender", "Male", "Female", "Other")
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            genderOptions
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        spinnerGender.adapter = adapter
        spinnerGender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                selectedGender = parent.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Do nothing
            }
        }
    }

    private fun setupClickListeners() {
        ivBack.setOnClickListener { finish() }

        btnSubmit.setOnClickListener {
            if (validateInputs()) {
                registerUserProfile()
            }
        }

        dateOfBirthEt.setOnClickListener {
            showDatePicker()
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val currentYear = calendar.get(Calendar.YEAR)
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)

        // Create date picker dialog
        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                // Format the selected date
                val selectedDate = formatSelectedDate(year, month, dayOfMonth)
                // Set the formatted date to the TextView
                dateOfBirthEt.text = selectedDate
            },
            currentYear,
            currentMonth,
            currentDay
        )
        datePickerDialog.datePicker.maxDate = System.currentTimeMillis()
        val minDateCalendar = Calendar.getInstance()
        minDateCalendar.add(Calendar.YEAR, -100)
        datePickerDialog.datePicker.minDate = minDateCalendar.timeInMillis

        // Show the dialog
        datePickerDialog.show()
    }

    private fun formatSelectedDate(year: Int, month: Int, day: Int): String {
        return String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, day)
    }

    private fun validateInputs(): Boolean {
        val name = nameEt.text.toString().trim()
        val email = emailEt.text.toString().trim()
        val phone = phoneNumberEt.text.toString().trim()
        val dob = dateOfBirthEt.text.toString().trim()

        return when {
            name.isEmpty() -> {
                showToast("Please enter your full name")
                false
            }

            name.length < 3 -> {
                showToast("Name should be at least 3 characters")
                false
            }

            email.isEmpty() -> {
                showToast("Please enter your email address")
                false
            }

            !isValidEmail(email) -> {
                showToast("Please enter a valid email address")
                false
            }

            phone.isEmpty() -> {
                showToast("Please enter your phone number")
                false
            }

            !isValidPhone(phone) -> {
                showToast("Please enter a valid 10-digit phone number")
                false
            }

            selectedGender == "Select Gender" -> {
                showToast("Please select your gender")
                false
            }

            dob.isEmpty() -> {
                showToast("Please enter your date of birth")
                false
            }

            !isValidDob(dob) -> {
                showToast("You must be at least 7 years old")
                false
            }

            else -> true
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun isValidPhone(phone: String): Boolean {
        return phone.length == 10 && phone.all { it.isDigit() }
    }

    private fun isValidDob(dob: String): Boolean {
        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            sdf.isLenient = false
            val birthDate = sdf.parse(dob) ?: return false

            val minAge = Calendar.getInstance().apply {
                add(Calendar.YEAR, -7)
            }

            return birthDate.before(minAge.time)
        } catch (e: Exception) {
            return false
        }
    }

    private fun registerUserProfile() {
        // Get authorization token from shared preferences
        val authToken = authToken ?: ""

        val request = userRegisterRequest(
            phone = phoneNumberEt.text.toString(),
            userName = nameEt.text.toString(),
            email = emailEt.text.toString(),
            dob = dateOfBirthEt.text.toString(),
            image = "",
            referralCode = ""
            // Add gender if your API supports it
            // gender = selectedGender
        )

        viewModel.userRegister(authToken, request)
    }

    private fun setupObservers() {
        lifecycleScope.launchWhenStarted {
            viewModel.userRegisterRequest.collectLatest { result ->
                when (result) {
                    is ApiResult.Loading -> showProgress(true)
                    is ApiResult.Success -> handleRegistrationSuccess(result.data)
                    is ApiResult.Error -> handleError(result.message)
                    null -> Unit
                }
            }
        }
    }

    private fun handleRegistrationSuccess(response: userRegisterResponse) {
        if (response.responseCode == 200) {
            showToast("Profile created successfully!")
        } else {
            showError(response.message)
        }
    }

    private fun handleError(message: String) {
        showToast("Error: $message")
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showProgress(show: Boolean) {

    }

    private fun showError(message: String) {
        showToast("Error: $message")
    }

    private fun initialAPICall() {
        // ViewModel initialization
        val repository = AuthRepository()
        userProfileViewModel = ViewModelProvider(
            this,
            GetUserDetailsModelFactory(repository)
        ).get(ViewModel.getUserViewModel::class.java)
        userProfileViewModel.userData.observe(this, { userData ->
            ProgressBarUtility.dismissProgressDialog()
            nameEt.text = userData.userName
            emailEt.text = userData.email
            phoneNumberEt.text = userData.phone
            dateOfBirthEt.text = userData.dob

        })


        userProfileViewModel.isLoading.observe(this) { isLoading ->
            // Update loading UI
        }

        // Keep 'this' for Toast in Activity
        userProfileViewModel.error.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        }

        userProfileViewModel.fetchuserDetails(authToken)
    }

}