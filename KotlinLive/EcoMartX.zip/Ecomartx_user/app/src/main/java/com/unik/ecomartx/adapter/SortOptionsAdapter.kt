package com.unik.ecomartx.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.unik.ecomartx.R
import com.unik.ecomartx.copy
import com.unik.ecomartx.model.SortOption
import com.unik.ecomartx.model.SortType

class SortOptionsAdapter(
    private val options: List<SortOption>,
    private val onOptionSelected: (SortType) -> Unit,
    private val onDismissRequested: () -> Unit // Add dismiss callback
) : RecyclerView.Adapter<SortOptionsAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val radioButton: RadioButton = itemView.findViewById(R.id.radioButton)
        val optionText: TextView = itemView.findViewById(R.id.optionText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_sort_option, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val option = options[position]
        holder.optionText.text = option.label

        holder.radioButton.setOnCheckedChangeListener(null)
        holder.radioButton.isChecked = option.isSelected

        holder.itemView.setOnClickListener {
            onOptionSelected(option.type)
            onDismissRequested() // Request dialog dismissal
        }

        holder.radioButton.setOnClickListener {
            onOptionSelected(option.type)
            onDismissRequested() // Request dialog dismissal
        }
    }

    override fun getItemCount() = options.size
}