package com.unik.ecomartx

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.os.Build
import androidx.annotation.RequiresApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.SocketException

fun Context.getLocalIpAddress(): String? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getIpAddressModern()
        } else {
            getIpAddressLegacy()
        }
    } catch (e: Exception) {
        null
    }
}

@RequiresApi(Build.VERSION_CODES.M)
private fun Context.getIpAddressModern(): String? {
    val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetwork: Network? = connectivityManager.activeNetwork

    activeNetwork?.let { network ->
        val linkProperties: LinkProperties? = connectivityManager.getLinkProperties(network)
        linkProperties?.linkAddresses?.forEach { address ->
            val ip = address.address
            if (ip is Inet4Address && !ip.isLoopbackAddress) {
                return ip.hostAddress
            }
        }
    }
    return null
}

private fun getIpAddressLegacy(): String? {
    try {
        val interfaces: List<NetworkInterface> =
            NetworkInterface.getNetworkInterfaces().toList()

        for (intf in interfaces) {
            if (!intf.isUp || intf.isLoopback) continue

            for (addr in intf.inetAddresses.toList()) {
                if (addr.isLoopbackAddress || addr.hostAddress.contains(":")) continue

                if (addr is Inet4Address) {
                    return addr.hostAddress
                }
            }
        }
    } catch (ex: SocketException) {
        ex.printStackTrace()
    }
    return null
}



