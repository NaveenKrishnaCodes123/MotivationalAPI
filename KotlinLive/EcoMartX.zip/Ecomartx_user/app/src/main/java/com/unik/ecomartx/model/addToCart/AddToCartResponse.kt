package com.unik.ecomartx.model.addToCart

import java.util.Date

data class AddToCartResponse(
    val responseCode: Int,
    val message: String,
    val cart: Cart
)

data class Cart(
    val user: String,
    val items: List<CartItem>,
    val discount: Int,
    val address: String,
    val gst: Int,
    val subTotal: Int,
    val finalPrice: Int,
    val deliveryFee: Int,
    val id: String,
    val createdAt: Date,
    val updatedAt: Date,
    val v: Int
)

data class CartItem(
    val item: String,
    val itemName: String,
    val price: Int,
    val purchaseQuantity: Int,
    val discount: Int,
    val gst: Int,
    val subTotal: Int,
    val finalPrice: Int,
    val _id: String
)
