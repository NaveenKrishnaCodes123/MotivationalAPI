package com.unik.ecomartx

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import com.unik.ecomartx.adapter.FoodItemsListAdapter
import com.unik.ecomartx.model.NearbyRestaurants.MenuItem
import com.unik.ecomartx.model.NearbyRestaurants.MenuItemApiResponse
import com.unik.ecomartx.model.NearbyRestaurants.GetRestaurentsById
import com.unik.ecomartx.model.SortType
import com.unik.ecomartx.model.addToCart.AddToCartRequest
import com.unik.ecomartx.model.addToCart.AddToCartResponse
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.flow.collectLatest

class RestaurantDetailActivity : AppCompatActivity() {

    private lateinit var rvFoodItems: RecyclerView
    private lateinit var cartBadge: TextView
    private lateinit var btnCheckout: Button
    private lateinit var backButton: ImageView
    private lateinit var searchView: SearchView
    private lateinit var sortButton: TextView
    private lateinit var filterVeg: TextView
    private lateinit var filterNonVeg: TextView
    private lateinit var restaurant: TextView

    private lateinit var adapter: FoodItemsListAdapter
    private var cartItemCount = 0
    private val viewModel: ViewModel by viewModels()
    private lateinit var authToken: String
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper
    private  var defaultAddress: String="Address"

    private var allMenuItems: List<MenuItem> = emptyList()
    private var currentFilter = FilterType.ALL
    private var currentQuery = ""
    private var currentSort = SortType.POPULARITY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resturant_detail)

        val categoryId = intent.getStringExtra("categoryId") ?: ""
        val restaurantToken = intent.getStringExtra("restaurantToken") ?: ""
        val restaurantName = intent.getStringExtra("restaurantName") ?: ""

        sharedPreferencesHelper = SharedPreferencesHelper(this)
        authToken = getAuthToken()
        //defaultAddress = getDefaultAddress()

        initViews(restaurantName)
        setupListeners()
        fetchMenuItems(restaurantToken, categoryId)
        setupObservers()
        setupCartObserver()
    }

    private fun getAuthToken(): String {
        return sharedPreferencesHelper.getLoginResponse()?.user?.token ?: run {
            Toast.makeText(this, "Please login again", Toast.LENGTH_SHORT).show()
            finish()
            ""
        }
    }

//    private fun getDefaultAddress(): String {
//        // Implement your actual address fetching logic here
//        return sharedPreferencesHelper.getDefaultAddressId() ?: "684177ee48141d1fd1309dff"
//    }

    private fun initViews(restaurantName: String) {
        rvFoodItems = findViewById(R.id.rvFoodItems)
        cartBadge = findViewById(R.id.cartBadge)
        btnCheckout = findViewById(R.id.btnCheckout)
        backButton = findViewById(R.id.backButton)
        searchView = findViewById(R.id.searchView)
        sortButton = findViewById(R.id.sort)
        filterVeg = findViewById(R.id.filterVeg)
        filterNonVeg = findViewById(R.id.filterNonVeg)
        restaurant = findViewById(R.id.restaurentName)

        rvFoodItems.layoutManager = LinearLayoutManager(this)
        restaurant.text = restaurantName

        adapter = FoodItemsListAdapter(
            emptyList(),
            { count ->
                cartItemCount = count
                updateCartBadge(count)
            },
            { item, quantity ->
                addItemToCart(item, quantity)
            }
        )
        rvFoodItems.adapter = adapter

        btnCheckout.visibility = View.GONE
        cartBadge.visibility = View.GONE
    }

    private fun setupListeners() {
        backButton.setOnClickListener { finish() }

        btnCheckout.setOnClickListener {
            val cartItems = adapter.getCartItems()
            if (cartItems.isNotEmpty()) {
                val intent = Intent(this, CartActivity::class.java).apply {
                    putExtra("cartItems", ArrayList(cartItems))
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show()
            }
        }

        sortButton.setOnClickListener { showSortOptionsDialog() }
        filterVeg.setOnClickListener { applyFilter(FilterType.VEG) }
        filterNonVeg.setOnClickListener { applyFilter(FilterType.NON_VEG) }

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                currentQuery = query
                applyFiltersAndSort()
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                currentQuery = newText
                applyFiltersAndSort()
                return true
            }
        })

        searchView.setOnCloseListener {
            currentQuery = ""
            applyFiltersAndSort()
            false
        }
    }

    private fun showSortOptionsDialog() {
        SortOptionsDialog(this, currentSort) { selectedSort ->
            currentSort = selectedSort
            applyFiltersAndSort()
            updateSortButtonText()
        }.show()
    }

    private fun updateSortButtonText() {
        val sortText = when (currentSort) {
            SortType.NAME_A_TO_Z -> "Name (A-Z)"
            SortType.PRICE_LOW_TO_HIGH -> "Price (Low to High)"
            SortType.PRICE_HIGH_TO_LOW -> "Price (High to Low)"
            SortType.DISCOUNT_HIGHEST -> "Discount (%)"
            SortType.POPULARITY -> "Popularity"
        }
        sortButton.text = "Sort: $sortText"
    }

    private fun fetchMenuItems(restaurantToken: String, categoryId: String) {
        val request = GetRestaurentsById(
//            restaurantId = restaurantToken,
//            category = categoryId,
            restaurantId = "684142802f62ec6da9fc6eb5",
            category = "68401a398bbb901b33730c15",
            search = "",
            page = 1,
            limit = 20
        )
        viewModel.getRestaurentItems(authToken, request)
    }

    private fun setupObservers() {
        lifecycleScope.launchWhenStarted {
            viewModel.getRestaurentItemsRequest.collectLatest { result ->
                when (result) {
                    is ApiResult.Loading -> showProgress(true)
                    is ApiResult.Success -> handleSuccess(result.data)
                    is ApiResult.Error -> handleError(result.message)
                    else -> {}
                }
            }
        }
    }

    private fun setupCartObserver() {
        lifecycleScope.launchWhenStarted {
            viewModel.addToCart.collectLatest { result ->
                when (result) {
                    is ApiResult.Loading -> showCartProgress(true)
                    is ApiResult.Success -> handleCartSuccess(result.data)
                    is ApiResult.Error -> handleCartError(result.message)
                    else -> {}
                }
            }
        }
    }

    private fun handleSuccess(response: MenuItemApiResponse) {
        showProgress(false)
        if (response.responseCode == 200) {
            allMenuItems = response.data ?: emptyList()
            applyFiltersAndSort()
        } else {
            Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleError(message: String) {
        showProgress(false)
        Toast.makeText(this, "Error: $message", Toast.LENGTH_SHORT).show()
    }

    private fun showProgress(show: Boolean) {
        // Implement your progress indicator
    }

    private fun updateCartBadge(count: Int) {
        if (count > 0) {
            cartBadge.visibility = View.VISIBLE
            btnCheckout.visibility = View.VISIBLE
            cartBadge.text = count.toString()
        } else {
            cartBadge.visibility = View.GONE
            btnCheckout.visibility = View.GONE
        }
    }

    private fun applyFilter(filterType: FilterType) {
        currentFilter = filterType
        applyFiltersAndSort()
        updateFilterUI()
    }

    private fun applyFiltersAndSort() {
        var filteredList = allMenuItems

        filteredList = when (currentFilter) {
            FilterType.ALL -> filteredList
            FilterType.VEG -> filteredList.filter { isVegItem(it) }
            FilterType.NON_VEG -> filteredList.filter { !isVegItem(it) }
        }

        if (currentQuery.isNotEmpty()) {
            filteredList = filteredList.filter {
                it.name.contains(currentQuery, true) ||
                        it.description.contains(currentQuery, true)
            }
        }

        filteredList = when (currentSort) {
            SortType.NAME_A_TO_Z -> filteredList.sortedBy { it.name }
            SortType.PRICE_LOW_TO_HIGH -> filteredList.sortedBy { it.priceDiscounted }
            SortType.PRICE_HIGH_TO_LOW -> filteredList.sortedByDescending { it.priceDiscounted }
            SortType.DISCOUNT_HIGHEST -> filteredList.sortedByDescending {
                ((it.priceOriginal - it.priceDiscounted) / it.priceOriginal * 100).toInt()
            }
            SortType.POPULARITY -> filteredList.sortedByDescending { it.popularity }
        }

        adapter.updateData(filteredList)
    }

    private fun isVegItem(item: MenuItem): Boolean {
        val nonVegKeywords = listOf("non-veg", "chicken", "mutton", "fish", "egg")
        return !nonVegKeywords.any { keyword ->
            item.foodType?.contains(keyword, ignoreCase = true) == true ||
                    item.name?.contains(keyword, ignoreCase = true) == true
        }
    }

    private fun updateFilterUI() {
        val defaultBg = ContextCompat.getDrawable(this, R.drawable.rounded_image)
        val selectedBg = ContextCompat.getDrawable(this, R.drawable.rounded_border_with_fill)

        sortButton.background = defaultBg
        filterVeg.background = defaultBg
        filterNonVeg.background = defaultBg

        when (currentFilter) {
            FilterType.ALL -> sortButton.background = selectedBg
            FilterType.VEG -> filterVeg.background = selectedBg
            FilterType.NON_VEG -> filterNonVeg.background = selectedBg
        }
    }

    private fun addItemToCart(item: MenuItem, quantity: Int) {
        val request = AddToCartRequest(
            item = item.id,
            itemName = item.name ?: "Unnamed Item",
            price = item.priceDiscounted?.toInt() ?: 0,
            purchaseQuantity = quantity,
            discount = 0,
            gst = 0,
            address = defaultAddress
        )
        viewModel.addToCart(authToken, request)
    }

    private fun showCartProgress(show: Boolean) {
        // Implement cart progress indicator
    }

    private fun handleCartSuccess(response: AddToCartResponse) {
        showCartProgress(false)
        if (response.responseCode == 200) {
            // Cart updated successfully
            Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleCartError(message: String) {
        showCartProgress(false)
        Toast.makeText(this, "Cart error: $message", Toast.LENGTH_SHORT).show()
    }

    enum class FilterType {
        ALL, VEG, NON_VEG
    }
}