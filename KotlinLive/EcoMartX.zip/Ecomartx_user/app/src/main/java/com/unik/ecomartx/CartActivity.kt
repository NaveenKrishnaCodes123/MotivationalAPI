package com.unik.ecomartx

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mindcoin.dservicevp.loader.ProgressBarUtility
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import com.unik.ecomartx.adapter.CartAdapter
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartRequest
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartResponse
import com.unik.ecomartx.modelimport.CartItemList
import com.unik.ecomartx.repository.AuthRepository
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.flow.collectLatest
import java.util.Calendar

class CartActivity : AppCompatActivity() {
    private lateinit var viewModelgetCartData: ViewModel.getListOfCartItems
    private val viewModel: ViewModel by viewModels()
    private lateinit var tvCartSummary: TextView
    private lateinit var btnCheckout: Button
    private lateinit var rvFoodItems: RecyclerView
    private lateinit var adapter: CartAdapter
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper
    private lateinit var authToken: String

    private var isExpanded = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        rvFoodItems = findViewById(R.id.rvFoodItems)
        val backButton = findViewById<ImageView>(R.id.backButton)


        rvFoodItems.layoutManager = LinearLayoutManager(this)

        sharedPreferencesHelper = SharedPreferencesHelper(this)
        authToken = getAuthToken()
        val loginResponse = sharedPreferencesHelper.getLoginResponse()
        loginResponse?.let {
            val loginData = it.user
            if (loginData != null) {
                authToken = loginData.token ?: "N/A"
            }
        } ?: run {
            Toast.makeText(this, "Please Logout and Login Once.", Toast.LENGTH_SHORT).show()
        }

        backButton.setOnClickListener {
            finish()
        }

        // Initialize adapter with removal callback
        adapter = CartAdapter(
            mutableListOf(),
            onItemRemoved = { itemId ->
                removeProductFromCartApi(itemId)
            }
        )
        rvFoodItems.adapter = adapter

        getCartData()
        setupObservers()
    }

    private fun getAuthToken(): String {
        return sharedPreferencesHelper.getLoginResponse()?.user?.token ?: run {
            Toast.makeText(this, "Please login again", Toast.LENGTH_SHORT).show()
            finish()
            ""
        }
    }

    private fun getCartData() {
        val repository = AuthRepository()
        viewModelgetCartData = ViewModelProvider(this, GetCartItemsList(repository)).get(ViewModel.getListOfCartItems::class.java)
        viewModelgetCartData.cardData.observe(this) { cartItems ->
            ProgressBarUtility.dismissProgressDialog()
            adapter.updateData(cartItems)
        }

        viewModelgetCartData.isLoading.observe(this) { isLoading ->
            if (isLoading) ProgressBarUtility.showProgressDialog(this)
        }

        viewModelgetCartData.error.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        }

        // Fetch initial cart data
        viewModelgetCartData.getListOfCartItems(authToken)
    }

    private fun removeProductFromCartApi(itemId: String) {
        val authToken = authToken
        if (authToken.isEmpty()) {
            Toast.makeText(this, "Authentication required", Toast.LENGTH_SHORT).show()
            return
        }

        val request = RemoveProductFromCartRequest(itemId = itemId)
        viewModel.removeProductFromCart(authToken, request)
    }

    private fun setupObservers() {
        lifecycleScope.launchWhenStarted {
            viewModel.removeProductFromCart.collectLatest { result ->
                when (result) {
                    is ApiResult.Loading -> showProgress(true)
                    is ApiResult.Success -> {
                        showProgress(false)
                        if (result.data.responseCode == 200) {
                            // Refresh cart data after successful removal
                            viewModelgetCartData.getListOfCartItems(authToken)
                        } else {
                            showError(result.data.message)
                        }
                    }
                    is ApiResult.Error -> {
                        showProgress(false)
                        showError(result.message)
                        // Refresh cart to revert UI changes on error
                        viewModelgetCartData.getListOfCartItems(authToken)
                    }
                    null -> Unit
                }
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showProgress(show: Boolean) {
        if (show) ProgressBarUtility.showProgressDialog(this)
        else ProgressBarUtility.dismissProgressDialog()
    }

    private fun showError(message: String) {
        showToast("Error: $message")
    }
}