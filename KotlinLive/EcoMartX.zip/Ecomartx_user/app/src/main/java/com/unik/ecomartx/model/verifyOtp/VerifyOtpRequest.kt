package com.unik.ecomartx.model.verifyOtp

data class VerifyOtpRequest(
    val phone: String,
    val otp: Int,
    val deviceId: String
)