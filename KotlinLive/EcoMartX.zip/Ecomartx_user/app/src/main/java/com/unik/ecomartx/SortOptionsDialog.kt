package com.unik.ecomartx

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Window
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.unik.ecomartx.R
import com.unik.ecomartx.adapter.SortOptionsAdapter
import com.unik.ecomartx.model.SortOption
import com.unik.ecomartx.model.SortType

class SortOptionsDialog(
    context: Context,
    private var currentSort: SortType,
    private val onSortSelected: (SortType) -> Unit
) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_sort_options)

        val recyclerView = findViewById<RecyclerView>(R.id.rvSortOptions)
        recyclerView.layoutManager = LinearLayoutManager(context)

        val options = listOf(
            SortOption("Name (A-Z)", SortType.NAME_A_TO_Z, currentSort == SortType.NAME_A_TO_Z),
            SortOption("Price (Low to High)", SortType.PRICE_LOW_TO_HIGH, currentSort == SortType.PRICE_LOW_TO_HIGH),
            SortOption("Price (High to Low)", SortType.PRICE_HIGH_TO_LOW, currentSort == SortType.PRICE_HIGH_TO_LOW),
            SortOption("Discount (%)", SortType.DISCOUNT_HIGHEST, currentSort == SortType.DISCOUNT_HIGHEST),
            SortOption("Popularity", SortType.POPULARITY, currentSort == SortType.POPULARITY)
        )

        recyclerView.adapter = SortOptionsAdapter(options,
            onOptionSelected = { selectedSort ->
                onSortSelected(selectedSort)
            },
            onDismissRequested = {
                dismiss() // Dismiss dialog when requested
            }
        )
    }

}