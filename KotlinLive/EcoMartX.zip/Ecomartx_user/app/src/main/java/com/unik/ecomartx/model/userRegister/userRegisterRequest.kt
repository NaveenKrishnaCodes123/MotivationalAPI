package com.unik.ecomartx.model.userRegister

data class userRegisterRequest(
 val phone :String,
 val userName :String,
 val email :String,
 val dob :String,
 val image :String,
 val referralCode :String
)