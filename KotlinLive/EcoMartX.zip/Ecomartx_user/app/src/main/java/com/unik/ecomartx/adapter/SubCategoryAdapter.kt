package com.unik.ecomartx.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.imageview.ShapeableImageView
import com.unik.ecomartx.R
import com.unik.ecomartx.model.NearbyRestaurants.Restaurant

class SubCategoryAdapter(
    private var restaurantList: List<Restaurant> =emptyList(),
    private val onItemClick: (Restaurant,position:Int) -> Unit
) : RecyclerView.Adapter<SubCategoryAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.foodNameSubCategory)
        val imageView: ShapeableImageView = itemView.findViewById(R.id.foodImagesubCategory)
        val foodDesc: TextView = itemView.findViewById(R.id.foodDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subcategory, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val restaurant = restaurantList[position]

        holder.name.text = restaurant.name
      //  holder.foodDesc.text = restaurant.address

        // Load first image if available
        restaurant.images.firstOrNull()?.let { imageUrl ->
            Glide.with(holder.itemView.context)
                .load("https://ecomartx.s3.ap-south-1.amazonaws.com/$imageUrl")
                .placeholder(R.drawable.beverages)
                .into(holder.imageView)
        }

        // Click listener
        holder.itemView.setOnClickListener {
            onItemClick(restaurant,position)
        }
    }

    override fun getItemCount() = restaurantList.size

    fun updateData(newList: List<Restaurant>) {
        restaurantList = newList
        notifyDataSetChanged()
    }

}
