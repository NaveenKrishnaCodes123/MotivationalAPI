package com.unik.ecomartx.model

data class Food(
    val name: String,
    val image: Int
)