package com.unik.ecomartx.model.removeProductFromCart

data class RemoveProductFromCartResponse(
val responseCode: Int,
val message: String,
val removedItem: RemovedItem,
)
data class RemovedItem(
    val item: String,
    val itemName: String,
    val price: Int,
    val purchaseQuantity: Int,
    val discount: Int,
    val gst: Int,
    val subTotal: Int,
    val finalPrice: Int,
    val _id: String,
)