package com.unik.ecomartx.model.address

import com.google.gson.annotations.SerializedName
import java.util.Date

data class AddAddressResponse(
    @SerializedName("responseCode") val responseCode: Int,
    @SerializedName("message") val message: String,
    @SerializedName("address") val address: AddressDetail
)

data class AddressDetail(
    @SerializedName("user") val userId: String,
    @SerializedName("area") val area: String,
    @SerializedName("streetName") val streetName: String,
    @SerializedName("landMark") val landmark: String,
    @SerializedName("city") val city: String,
    @SerializedName("pincode") val pincode: String,
    @SerializedName("state") val state: String,
    @SerializedName("country") val country: String,
    @SerializedName("addressType") val addressType: String,
    @SerializedName("isDefault") val isDefault: Boolean,
    @SerializedName("location") val location: GeoLocation,
    @SerializedName("isActive") val isActive: Boolean,
    @SerializedName("isDeleted") val isDeleted: Boolean,
    @SerializedName("name") val name: String,
    @SerializedName("phone") val phone: String,
    @SerializedName("_id") val id: String,
    @SerializedName("createdAt") val createdAt: Date,
    @SerializedName("updatedAt") val updatedAt: Date,
    @SerializedName("__v") val version: Int
)

data class GeoLocation(
    @SerializedName("type") val type: String,
    @SerializedName("coordinates") val coordinates: List<Double>
)