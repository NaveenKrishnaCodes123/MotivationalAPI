package com.mindcoin.dservicevp.apis

import com.unik.ecomartx.model.MobileCategories
import com.unik.ecomartx.model.NearbyRestaurants.GetRestaurentsById
import com.unik.ecomartx.model.NearbyRestaurants.MenuItemApiResponse
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsRequest
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsResponse
import com.unik.ecomartx.model.addToCart.AddToCartRequest
import com.unik.ecomartx.model.addToCart.AddToCartResponse
import com.unik.ecomartx.model.address.AddAddressRequest
import com.unik.ecomartx.model.address.AddAddressResponse
import com.unik.ecomartx.model.generateOTP.GenerateOtpRequest
import com.unik.ecomartx.model.generateOTP.GenerateOtpResponse
import com.unik.ecomartx.model.getUserProfile.UserProfileResponse
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartRequest
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartResponse
import com.unik.ecomartx.model.userRegister.userRegisterRequest
import com.unik.ecomartx.model.userRegister.userRegisterResponse
import com.unik.ecomartx.model.verifyOtp.VerifyOtpRequest
import com.unik.ecomartx.model.verifyOtp.VerifyOtpResponse
import com.unik.ecomartx.modelimport.GetListOfCartItemsResponse
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST


interface ApiService {
    companion object {
        val api: ApiService = RetrofitClient.create(ApiService::class.java)
    }

    @POST("user/generateUserOTP")
    fun generateOtp(@Body request: GenerateOtpRequest): Call<GenerateOtpResponse>

    @POST("user/verifyOtp")
    suspend fun verifyOtp(@Body request: VerifyOtpRequest): Response<VerifyOtpResponse>

    @POST("user/getNearbyRestaurants")
    suspend fun getNearbyRestaurants(
        @Header("Authorization") authToken: String,
        @Body request: NearByRestaurentsRequest
    ): Response<NearByRestaurentsResponse>

    @POST("user/addToCart")
    suspend fun addToCart(
        @Header("Authorization") authToken: String,
        @Body request: AddToCartRequest
    ): Response<AddToCartResponse>

    @GET("user/getMobileCategories")
    fun getMobileCategories(@Header("Authorization") authToken: String): Call<MobileCategories>

    @GET("user/GetListOfCartItems")
    fun getListOfCartItems(@Header("Authorization") authToken: String): Call<GetListOfCartItemsResponse>


    @GET("user/getUserProfile")
    fun getUserProfile(@Header("Authorization") authToken: String): Call<UserProfileResponse>

    @POST("getMenuItems")
    suspend fun getRestaurentItems(
        @Header("Authorization") authToken: String,
        @Body request: GetRestaurentsById
    ): Response<MenuItemApiResponse>

    @POST("user/RemoveProductFromCart")
    suspend fun removeProductFromCart(
        @Header("Authorization") authToken: String,
        @Body request: RemoveProductFromCartRequest
    ): Response<RemoveProductFromCartResponse>


    @POST("user/registerUser")
    suspend fun registerUser(
        @Header("Authorization") authToken: String,
        @Body request: userRegisterRequest
    ): Response<userRegisterResponse>

    @POST("/user/addAddress")
    suspend fun addAddress(
        @Header("Authorization") authToken: String,
        @Body request: AddAddressRequest
    ): Response<AddAddressResponse>


}