package com.unik.ecomartx.model.verifyOtp

data class VerifyOtpResponse(
    val responseCode: Int,
    val message: String,
    val user: User
)

data class User(
    val _id: String,
    val phone: String,
    val isRegistered: Boolean,
    val status: String,
    val source: String,
    val createdAt: String,
    val updatedAt: String,
    val __v: Int,
    val token: String,
    val location: Location
)

data class Location(
    val type: String,
    val coordinates: List<Double>
)
