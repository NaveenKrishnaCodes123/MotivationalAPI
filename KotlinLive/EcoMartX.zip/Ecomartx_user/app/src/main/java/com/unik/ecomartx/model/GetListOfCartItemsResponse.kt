package com.unik.ecomartx.modelimport

data class GetListOfCartItemsResponse(
    val responseCode: Int,
    val message: String,
    val cartId: String,
    val items: List<CartItemList>,
    val discount: Int,
    val gst: Int,
    val subTotal: Int,
    val finalPrice: Int,
    val deliveryCharges: Int
)

data class CartItemList(
    val item: String,
    val itemName: String,
    val price: Int,
    var purchaseQuantity: Int,
    val discount: Int,
    val gst: Int,
    val subTotal: Int,
    val finalPrice: Int,
    val _id: String,
    val image: List<String>
)