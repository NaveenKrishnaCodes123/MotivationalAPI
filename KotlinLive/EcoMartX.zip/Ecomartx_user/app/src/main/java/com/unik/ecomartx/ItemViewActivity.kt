package com.unik.ecomartx

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.unik.ecomartx.adapter.FoodItemsAdapter
import com.unik.ecomartx.model.Food

class ItemViewActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FoodItemsAdapter
    private lateinit var btnToggleView: ImageButton
    private lateinit var ivBack: ImageView
    private lateinit var tvTitle: TextView

    private var isGridView = false // Toggle state flag

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_view)

        recyclerView = findViewById(R.id.rvitems)
        btnToggleView = findViewById(R.id.btnToggleView)
        ivBack = findViewById(R.id.ivBack)
        tvTitle = findViewById(R.id.tvTitle)

        val categoryName = intent.getStringExtra("categoryName")
        tvTitle.text = categoryName

        val foodItems = listOf(
            Food("Sravan Kitchen $categoryName", R.drawable.eco_sravan),
            Food("Manish $categoryName", R.drawable.eco_manish),
            Food("Uday $categoryName", R.drawable.eco_sravan),
            Food("Dhiraj $categoryName", R.drawable.eco_manish)
        )

        ivBack.setOnClickListener {
            finish()
        }

        adapter = FoodItemsAdapter(foodItems) { food ->
            startActivity(Intent(this, RestaurantDetailActivity::class.java))
        }

        // Initial layout is ListView
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        btnToggleView.setOnClickListener {
            toggleLayout()
        }
    }

    private fun toggleLayout() {
        isGridView = !isGridView

        if (isGridView) {
            recyclerView.layoutManager = GridLayoutManager(this, 2)
            btnToggleView.setImageResource(R.drawable.ic_list_view) // icon for list view
        } else {
            recyclerView.layoutManager = LinearLayoutManager(this)
            btnToggleView.setImageResource(R.drawable.ic_grid_view) // icon for grid view
        }

        // Notify adapter to rebind if needed
        recyclerView.adapter = adapter
    }
}
