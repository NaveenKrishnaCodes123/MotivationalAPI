package com.unik.ecomartx.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.imageview.ShapeableImageView
import com.unik.ecomartx.R
import com.unik.ecomartx.model.NearbyRestaurants.MenuItem
import java.io.Serializable

class FoodItemsListAdapter(
    private var foodList: List<MenuItem> = emptyList(),
    private val onCartCountChanged: (Int) -> Unit,
    private val onCartItemChanged: (MenuItem, Int) -> Unit
) : RecyclerView.Adapter<FoodItemsListAdapter.MyViewHolder>() {

    data class CartItem(
        val id: String,
        val name: String,
        val description: String,
        val priceDiscounted: Float,
        val priceOriginal: Float,
        val image: String?,
        val quantity: Int
    ) : Serializable

    private val cartMap = mutableMapOf<String, Int>()

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val foodTitle: TextView = itemView.findViewById(R.id.foodTitle)
        val foodPrice: TextView = itemView.findViewById(R.id.foodPrice)
        val foodDescription: TextView = itemView.findViewById(R.id.foodDescription)
        val foodImage: ShapeableImageView = itemView.findViewById(R.id.foodImageView)
        val addButton: Button = itemView.findViewById(R.id.addButton)
        val quantityLayout: LinearLayout = itemView.findViewById(R.id.quantityLayout)
        val btnMinus: Button = itemView.findViewById(R.id.btnMinus)
        val btnPlus: Button = itemView.findViewById(R.id.btnPlus)
        val tvQuantity: TextView = itemView.findViewById(R.id.tvQuantity)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.food_items_singleview, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val foodItem = foodList[position]
        val currentQty = cartMap[foodItem.id] ?: 0

        holder.foodTitle.text = foodItem.name
        holder.foodPrice.text = formatPrice(foodItem.priceDiscounted, foodItem.priceOriginal)
        holder.foodDescription.text = foodItem.description

        // Safe image loading
        val firstImage = foodItem.image?.firstOrNull() ?: "default.jpg"
        Glide.with(holder.itemView.context)
            .load("https://ecomartx.s3.ap-south-1.amazonaws.com/$firstImage")
            .placeholder(R.drawable.beverages)
            .error(R.drawable.beverages)
            .into(holder.foodImage)

        updateQuantityUI(holder, currentQty)

        holder.addButton.setOnClickListener {
            cartMap[foodItem.id] = 1
            updateQuantityUI(holder, 1)
            triggerUpdate()
            onCartItemChanged(foodItem, 1)
        }

        holder.btnPlus.setOnClickListener {
            val newQty = (cartMap[foodItem.id] ?: 0) + 1
            cartMap[foodItem.id] = newQty
            updateQuantityUI(holder, newQty)
            triggerUpdate()
            onCartItemChanged(foodItem, newQty)
        }

        holder.btnMinus.setOnClickListener {
            val currentQty = cartMap[foodItem.id] ?: 0
            if (currentQty > 1) {
                val newQty = currentQty - 1
                cartMap[foodItem.id] = newQty
                updateQuantityUI(holder, newQty)
                triggerUpdate()
                onCartItemChanged(foodItem, newQty)
            } else {
                cartMap.remove(foodItem.id)
                updateQuantityUI(holder, 0)
                triggerUpdate()
                onCartItemChanged(foodItem, 0)
            }
        }
    }

    override fun getItemCount() = foodList.size

    private fun updateQuantityUI(holder: MyViewHolder, qty: Int) {
        if (qty > 0) {
            holder.addButton.visibility = View.GONE
            holder.quantityLayout.visibility = View.VISIBLE
            holder.tvQuantity.text = qty.toString()
        } else {
            holder.addButton.visibility = View.VISIBLE
            holder.quantityLayout.visibility = View.GONE
        }
    }

    private fun triggerUpdate() {
        onCartCountChanged(cartMap.values.sum())
    }

    fun getCartItems(): List<CartItem> {
        return cartMap.mapNotNull { (id, qty) ->
            foodList.firstOrNull { it.id == id }?.let { item ->
                CartItem(
                    id = item.id,
                    name = item.name,
                    description = item.description,
                    priceDiscounted = item.priceDiscounted,
                    priceOriginal = item.priceOriginal,
                    image = item.image?.firstOrNull(),
                    quantity = qty
                )
            }
        }
    }

    private fun formatPrice(discounted: Float, original: Float): String {
        return if (discounted < original) {
            "₹${"%.2f".format(discounted)} (₹${"%.2f".format(original)})"
        } else {
            "₹${"%.2f".format(original)}"
        }
    }

    fun updateData(newList: List<MenuItem>) {
        val newCartMap = mutableMapOf<String, Int>()
        newList.forEach { item ->
            cartMap[item.id]?.let { quantity ->
                newCartMap[item.id] = quantity
            }
        }

        foodList = newList
        cartMap.clear()
        cartMap.putAll(newCartMap)
        notifyDataSetChanged()
        triggerUpdate()
    }
}