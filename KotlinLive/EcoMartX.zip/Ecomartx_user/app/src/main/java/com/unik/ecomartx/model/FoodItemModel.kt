package com.unik.ecomartx.model

data class FoodItemModel(
    val foodItemName: String,
    val foodItemDescription: String,
    val rating: String,
    val price: String,
    val image: Int,
    var quantity: Int = 0  // for cart quantity tracking
)