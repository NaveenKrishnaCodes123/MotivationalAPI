package com.unik.ecomartx.model.NearbyRestaurants

data class GetRestaurentsById(
    val restaurantId: String,
    val category: String,
    val search: String,
    val page: Int,
    val limit: Int
)