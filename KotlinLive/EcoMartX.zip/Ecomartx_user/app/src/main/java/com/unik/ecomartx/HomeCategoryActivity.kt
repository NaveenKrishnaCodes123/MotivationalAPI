package com.unik.ecomartx


import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mindcoin.dservicevp.loader.ProgressBarUtility
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import com.unik.ecomartx.adapter.CategoriesAdapter
import com.unik.ecomartx.adapter.SubCategoryAdapter
import com.unik.ecomartx.repository.AuthRepository
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class HomeCategoryActivity : AppCompatActivity() {
    private lateinit var viewModelgetMobileCategories: ViewModel.getMobileCategories
    private lateinit var recyclerView: RecyclerView
    private lateinit var rvbanner: RecyclerView
    private lateinit var rvRestaurants: RecyclerView
    private lateinit var ivProfile: ImageView
    private lateinit var tvAddress: TextView
    private lateinit var addAddress: LinearLayout
    private lateinit var locationHelper: LocationHelper
    private var locationJob: Job? = null
    private var currentLatitude: Double = 0.0
    private var currentLongitude: Double = 0.0
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper
    private lateinit var authToken: String
    private lateinit var categoriesAdapter: CategoriesAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_categorys)

        rvRestaurants = findViewById(R.id.rvRestaurants)
        locationHelper = LocationHelper(this)
        ivProfile = findViewById(R.id.ivProfile)
        tvAddress = findViewById(R.id.tvAddress)
        addAddress = findViewById(R.id.addAddress)
        sharedPreferencesHelper = SharedPreferencesHelper(this)

        val loginResponse = sharedPreferencesHelper.getLoginResponse()
        loginResponse?.let {
            val loginData = it.user
            if (loginData != null) {
                authToken = loginData.token ?: "N/A"
            }
        } ?: run {
            Toast.makeText(this, "Please Logout and Login Once.", Toast.LENGTH_SHORT).show()
        }
        ivProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
        addAddress.setOnClickListener {
            startActivity(Intent(this, AddAddressActivity::class.java))
        }
        if (checkLocationPermission()) {
            getCurrentLocation()
        } else {
            requestLocationPermission()
        }
    }
    private fun checkLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLocation() {
        locationJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                val coords = withContext(Dispatchers.IO) {
                    locationHelper.getCurrentLatLong()
                }
                coords?.let { (longitude, latitude) ->
                    currentLongitude = longitude
                    currentLatitude = latitude
                    getAddressFromLocation(latitude, longitude)
                    getMobileCategories()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@HomeCategoryActivity,
                    "Location error: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun getMobileCategories() {
        val repository = AuthRepository()
        viewModelgetMobileCategories = ViewModelProvider(this, GetMobileCategories(repository)).get(ViewModel.getMobileCategories::class.java)
        val rvRestaurants = findViewById<RecyclerView>(R.id.rvRestaurants)
        rvRestaurants.layoutManager = GridLayoutManager(this, 4)
        categoriesAdapter = CategoriesAdapter(emptyList()){
                category,position ->
            val intent = Intent(this, SubCategoriesActivity::class.java)
            intent.putExtra("categoryId", category.categoryId)
            intent.putExtra("categoryName", category.name)
            intent.putExtra("currentLatitude", currentLatitude.toString())
            intent.putExtra("currentLongitude", currentLongitude.toString())
            startActivity(intent)
        }
        rvRestaurants.adapter = categoriesAdapter

        viewModelgetMobileCategories.categories.observe(this) { restaurants ->
            ProgressBarUtility.dismissProgressDialog()
            categoriesAdapter.updateData(restaurants)
        }

        viewModelgetMobileCategories.isLoading.observe(this) { isLoading ->
            if (isLoading) ProgressBarUtility.showProgressDialog(this)
        }
        viewModelgetMobileCategories.error.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        }
        // Fetch data
        viewModelgetMobileCategories.getMobileCategories(authToken)

    }



    private fun getAddressFromLocation(latitude: Double, longitude: Double) {
        val geocoder = Geocoder(this, Locale.getDefault())
        try {
            val addresses = geocoder.getFromLocation(latitude, longitude, 1)
            addresses?.firstOrNull()?.let { address ->
                tvAddress.text = (0..address.maxAddressLineIndex).joinToString("\n") {
                    address.getAddressLine(it)
                }
            } ?: run {
                tvAddress.text = "No address found"
            }
        } catch (e: Exception) {
            tvAddress.text = "Geocoder error"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1001
    }

}