package com.unik.ecomartx

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class LocationHelper(private val context: Context) {

    private val fusedLocationClient: FusedLocationProviderClient by lazy {
        LocationServices.getFusedLocationProviderClient(context)
    }

    private val locationSettingsClient: SettingsClient by lazy {
        LocationServices.getSettingsClient(context)
    }

    // Check if location permissions are granted
    fun hasLocationPermission(): Boolean {
        val fineLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return fineLocation || coarseLocation
    }

    // Get last known location if available
    @SuppressLint("MissingPermission")
    suspend fun getLastKnownLocation(): Location? = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) return@withContext null

        return@withContext suspendCoroutine<Location?> { continuation ->
            fusedLocationClient.lastLocation.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    continuation.resume(task.result)
                } else {
                    continuation.resume(null)
                }
            }
        }
    }

    // Get fresh location with timeout
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(
        priority: Int = LocationRequest.PRIORITY_HIGH_ACCURACY,
        timeout: Long = 30,
        timeUnit: TimeUnit = TimeUnit.SECONDS
    ): Location = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) {
            throw SecurityException("Location permission not granted")
        }

        // Create location request
        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            timeUnit.toMillis(timeout)
        ).apply {
            setMinUpdateIntervalMillis(1000)
            setMaxUpdates(1)
        }.build()

        // Check location settings
        checkLocationSettings(locationRequest)

        return@withContext suspendCoroutine<Location> { continuation ->
            val locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    locationResult.lastLocation?.let {
                        continuation.resume(it)
                    } ?: run {
                        continuation.resumeWithException(Exception("Null location received"))
                    }
                }

                override fun onLocationAvailability(availability: LocationAvailability) {
                    if (!availability.isLocationAvailable) {
                        continuation.resumeWithException(Exception("Location unavailable"))
                    }
                }
            }

            // Set timeout
            CoroutineScope(Dispatchers.IO).launch {
                delay(timeUnit.toMillis(timeout))
                continuation.resumeWithException(TimeoutException("Location request timed out"))
            }

            // Request location updates
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            ).addOnFailureListener { e ->
                continuation.resumeWithException(e)
            }

            // Cleanup on completion
//            continuation.invokeOnCancellation {
//                fusedLocationClient.removeLocationUpdates(locationCallback)
//            }
        }
    }

    // Main function to get coordinates
    suspend fun getCurrentLatLong(
    ): Pair<Double, Double>? = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) return@withContext null

        try {
            // Try to get last known location first if freshLocation not required

                getLastKnownLocation()?.let {
                    return@withContext Pair(it.longitude, it.latitude)

            }

            // Get fresh location with timeout
            val location = getCurrentLocation()
            return@withContext Pair(location.longitude, location.latitude)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Check if location services are enabled and sufficient
    private suspend fun checkLocationSettings(locationRequest: LocationRequest) {
        val locationSettingsRequest = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)
            .build()

        return suspendCoroutine { continuation ->
            locationSettingsClient.checkLocationSettings(locationSettingsRequest)
                .addOnSuccessListener { continuation.resume(Unit) }
                .addOnFailureListener { e ->
                    continuation.resumeWithException(e)
                }
        }
    }

    // Flow-based location updates (for continuous tracking)
    @SuppressLint("MissingPermission")
    fun locationFlow(
        priority: Int = LocationRequest.PRIORITY_HIGH_ACCURACY,
        interval: Long = 5000
    ): Flow<Location> = callbackFlow {
        if (!hasLocationPermission()) {
            close(SecurityException("Location permission not granted"))
            return@callbackFlow
        }

        val locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.locations.forEach { trySend(it).isSuccess }
            }
        }

        val locationRequest = LocationRequest.Builder(priority, interval).build()

        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        ).addOnFailureListener { e ->
            close(e)
        }

        awaitClose {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
    }
}