package com.unik.ecomartx.model.generateOTP

data class GenerateOtpRequest(
    val phone: String,
    val location: LocationData,
    val deviceId: String,
    val device_name: String,
    val ip: String,
    val city: String
)

data class LocationData(
    val type: String = "Point",
    val coordinates: List<Double>
)

