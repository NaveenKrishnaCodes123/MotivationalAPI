package com.unik.ecomartx.model

data class SortOption(
    val label: String,
    val type: SortType,
    val isSelected: Boolean
)
enum class SortType {
    NAME_A_TO_Z,
    PRICE_LOW_TO_HIGH,
    PRICE_HIGH_TO_LOW,
    DISCOUNT_HIGHEST,
    POPULARITY
}