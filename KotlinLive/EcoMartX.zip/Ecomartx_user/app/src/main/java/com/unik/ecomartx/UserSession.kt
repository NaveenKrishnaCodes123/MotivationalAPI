package com.unik.ecomartx

object UserSession {
    var _id: String? = null
    var phone: String? = null
    var __v: String? = null
    var token: String? = null

}
