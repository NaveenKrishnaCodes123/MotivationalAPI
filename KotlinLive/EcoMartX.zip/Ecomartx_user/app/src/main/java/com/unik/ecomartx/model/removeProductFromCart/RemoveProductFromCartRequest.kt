package com.unik.ecomartx.model.removeProductFromCart

data class RemoveProductFromCartRequest(
    val itemId: String
)