package com.unik.ecomartx.model.generateOTP

data class GenerateOtpResponse(
    val responseCode: Int,
    val message: String,
    val data: OtpData
)

data class OtpData(
    val phone: String,
    val otp: Int,
    val location: Location
)
data class Location(
    val type: String = "Point",
    val coordinates: List<Double>
)