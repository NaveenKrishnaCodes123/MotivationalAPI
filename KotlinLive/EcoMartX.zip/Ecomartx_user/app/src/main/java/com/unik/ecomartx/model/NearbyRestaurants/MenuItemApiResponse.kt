package com.unik.ecomartx.model.NearbyRestaurants

import com.google.gson.annotations.SerializedName


data class MenuItemApiResponse(
    val responseCode: Int,
    val message: String,
    val data: List<MenuItem>
)

data class MenuItem(
    @SerializedName("_id")
    val id: String,
    val restaurantId: String,
    val name: String,
    val description: String,
    val priceOriginal: Float,
    val priceDiscounted: Float,
    val categoryId: String,
    val subCategoryId: String,
    val quantity: Int,
    val isDeleted: Boolean,
    val image: List<String>,
    val isAvailable: Boolean,
    val createdAt: String,
    val version: Int,
    val popularity: Int = 0,
    val foodType: String
){
    fun isBestSeller(): Boolean {
        // Implement your bestseller logic
        // Example: items with discount > 20% are bestsellers
        val discountPercentage = ((priceOriginal - priceDiscounted) / priceOriginal * 100).toInt()
        return discountPercentage > 20
    }
}