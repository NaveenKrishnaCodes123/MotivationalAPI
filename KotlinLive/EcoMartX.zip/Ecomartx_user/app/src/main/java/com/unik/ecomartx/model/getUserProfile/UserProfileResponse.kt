package com.unik.ecomartx.model.getUserProfile

data class UserProfileResponse(
    val responseCode: Int,
    val message: String,
    val data: UserData
)

data class UserData(
    val location: Location,
    val id: String,
    val phone: String,
    val isRegistered: Boolean,
    val status: String,
    val source: String,
    val createdAt: String,
    val updatedAt: String,
    val version: Int,
    val token: String?,
    val customerId: String,
    val dob: String,
    val email: String,
    val image: String,
    val referralCode: String,
    val userName: String
)

data class Location(
    val type: String,
    val coordinates: List<Double>
)