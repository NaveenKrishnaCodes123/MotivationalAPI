package com.unik.ecomartx


import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.mindcoin.dservicevp.loader.NetworkUtils
import com.mindcoin.dservicevp.loader.ProgressBarUtility
import com.unik.ecomartx.model.generateOTP.GenerateOtpRequest
import com.unik.ecomartx.model.generateOTP.LocationData
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.Job
import android.provider.Settings
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginWithMobileActivity : AppCompatActivity() {
    private lateinit var otpViewModel: ViewModel
    private lateinit var locationHelper: LocationHelper
    private lateinit var longitudeValue : String
    private lateinit var latitudeValue : String


    private val LOCATION_PERMISSION_CODE = 100
    private var locationJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.loginwithmobile)
        otpViewModel = ViewModelProvider(this).get(ViewModel::class.java)
        val continuebtn = findViewById<Button>(R.id.continuebtn)
        val edtPhNO = findViewById<EditText>(R.id.edtPhNO)
        locationHelper = LocationHelper(this)
        continuebtn.setOnClickListener {
            if (NetworkUtils.isNetworkAvailable(this)) {
                val mobileNumber = edtPhNO.text.toString()
                if(!TextUtils.isEmpty(mobileNumber)&&mobileNumber.length>=10) {
                    ProgressBarUtility.showProgressDialog(this)

                    val ipAddress = this.getLocalIpAddress() ?: ""
                    val otpRequest = GenerateOtpRequest(
                        phone = edtPhNO.text.toString(),
                        location = LocationData(
                            type = "Point",
                            coordinates = listOf(longitudeValue.toDouble(), latitudeValue.toDouble())
                        ),
                        deviceId = Build.MODEL,
                        device_name = Build.MANUFACTURER,
                        ip = ipAddress,
                        city = ""
                    )
                    otpViewModel.otpRequest(otpRequest)
                }else {
                    Toast.makeText(this, "Please Enter Mobile Number", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show()
            }
        }
        otpViewModel.vehicleCheckInResponse.observe(this, Observer { resource ->
            when (resource) {
                is Resource.Loading -> {
                    ProgressBarUtility.showProgressDialog(this)
                }

                is Resource.Success -> {
                    val successMessage = resource.data?.message ?: ""
                    Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show()
                    ProgressBarUtility.dismissProgressDialog()
                    val intent = Intent(this, VerifyOTPActivity::class.java)
                    intent.putExtra("otp",resource.data?. data?.otp.toString()?:"")
                    intent.putExtra("txtPhno",edtPhNO.text.toString())
                    startActivity(intent)
                }

                is Resource.Failure -> {
                    ProgressBarUtility.dismissProgressDialog()
                }
            }
        })

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
            ) {
                setNotificationPermissionGranted(true)

            } else if (!isLocationPermissionGranted()) {
                showNotificationPermissionDialog()
            } else {
                showPermissionSettingsDialog()
            }
        }

        locationJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                val coords = withContext(Dispatchers.IO) {
                    locationHelper.getCurrentLatLong()
                }
                if (coords != null) {
                    val (longitude, latitude) = coords
                    longitudeValue= longitude.toString()
                    latitudeValue= latitude.toString()
                }
            } catch (e: Exception) {

            }
        }
    }
    private fun setNotificationPermissionGranted(granted: Boolean) {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("location_permission_granted", granted).apply()
    }
    private fun showNotificationPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("Location Permission Required")
            .setMessage("We need permission to send you important updates.")
            .setCancelable(false)
            .setPositiveButton("Allow") { _, _ ->
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.ACCESS_COARSE_LOCATION),
                    LOCATION_PERMISSION_CODE
                )
            }
            .setNegativeButton("Exit App") { _, _ ->
                finishAffinity()
            }
            .show()
    }

    private fun showPermissionSettingsDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permission Needed")
            .setMessage("You have permanently denied the notification permission. Please enable it in settings.")
            .setPositiveButton("Go to Settings") { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            }
            .setNegativeButton("Exit") { _, _ ->
                finishAffinity()
            }
            .show()
    }
    private fun isLocationPermissionGranted(): Boolean {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        return prefs.getBoolean("location_permission_granted", false)
    }
}