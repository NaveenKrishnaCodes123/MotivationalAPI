package com.unik.ecomartx.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.imageview.ShapeableImageView
import com.unik.ecomartx.R
import com.unik.ecomartx.modelimport.CartItemList

class CartAdapter(
    private var foodList: MutableList<CartItemList>,
    private val onItemRemoved: (String) -> Unit
) : RecyclerView.Adapter<CartAdapter.MyViewHolder>() {

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val foodImage: ShapeableImageView = itemView.findViewById(R.id.foodImage)
        val foodTitle: TextView = itemView.findViewById(R.id.foodTitle)
        val foodPrice: TextView = itemView.findViewById(R.id.foodPrice)
        val btnMinus: Button = itemView.findViewById(R.id.btnMinus)
        val btnPlus: Button = itemView.findViewById(R.id.btnPlus)
        val tvQuantity: TextView = itemView.findViewById(R.id.tvQuantity)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.cart_item, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val foodItem = foodList[position]

        holder.foodTitle.text = foodItem.itemName
        holder.foodPrice.text = "₹${foodItem.price}"
        holder.tvQuantity.text = foodItem.purchaseQuantity.toString()

        Glide.with(holder.itemView.context)
            .load("https://ecomartx.s3.ap-south-1.amazonaws.com/${foodItem.image}")
            .placeholder(R.drawable.beverages)
            .error(R.drawable.beverages)
            .into(holder.foodImage)

        // Handle minus button click
        holder.btnMinus.setOnClickListener {
            val newQuantity = foodItem.purchaseQuantity - 1
            /*if (newQuantity > 0) {
                // TODO: Implement quantity update API
                foodItem.purchaseQuantity = newQuantity
                holder.tvQuantity.text = newQuantity.toString()
                Toast.makeText(holder.itemView.context, "Quantity update not implemented", Toast.LENGTH_SHORT).show()
            } else {*/
                // Remove item from cart
            foodItem.purchaseQuantity = newQuantity
            holder.tvQuantity.text = newQuantity.toString()
                onItemRemoved(foodItem._id)
           // }
        }

        // Handle plus button click
        holder.btnPlus.setOnClickListener {
            val newQuantity = foodItem.purchaseQuantity + 1
            // TODO: Implement quantity update API
            foodItem.purchaseQuantity = newQuantity
            holder.tvQuantity.text = newQuantity.toString()
            Toast.makeText(holder.itemView.context, "Quantity update not implemented", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount() = foodList.size

    fun updateData(newList: List<CartItemList>) {
        foodList.clear()
        foodList.addAll(newList)
        notifyDataSetChanged()
    }
}