package com.unik.ecomartx
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import com.unik.ecomartx.model.verifyOtp.VerifyOtpResponse
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.flow.collectLatest

class VerifyOTPActivity : AppCompatActivity() {

    private val viewModel: ViewModel by viewModels()
    private lateinit var otp1: EditText
    private lateinit var otp2: EditText
    private lateinit var otp3: EditText
    private lateinit var otp4: EditText
    private lateinit var otp5: EditText
    private lateinit var otp6: EditText
    private lateinit var txtPhno: TextView
    private lateinit var btnSubmit: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.verifyotpactivity)

        val sharedPreferencesHelper = SharedPreferencesHelper(this)

        val titleback =findViewById<TextView>(R.id.titleback)
         txtPhno =findViewById<TextView>(R.id.txtPhno)
         btnSubmit =findViewById<Button>(R.id.btnVerify)
         otp1 =findViewById<EditText>(R.id.otp1)
         otp2 =findViewById<EditText>(R.id.otp2)
         otp3 =findViewById<EditText>(R.id.otp3)
         otp4 =findViewById<EditText>(R.id.otp4)
         otp5 =findViewById<EditText>(R.id.otp5)
         otp6 =findViewById<EditText>(R.id.otp6)

        titleback.setOnClickListener {
            finish()
        }
        setupObservers(sharedPreferencesHelper)
        setupOtpBoxes()

        handleIncomingOtp()

        btnSubmit.setOnClickListener { verifyOtp() }


    }

    private fun setupOtpBoxes() {
        otp1.addTextChangedListener(OtpTextWatcher(otp1, otp2))
        otp2.addTextChangedListener(OtpTextWatcher(otp2, otp3))
        otp3.addTextChangedListener(OtpTextWatcher(otp3, otp4))
        otp4.addTextChangedListener(OtpTextWatcher(otp4, otp5))
        otp5.addTextChangedListener(OtpTextWatcher(otp5, otp6))
        otp6.addTextChangedListener(OtpTextWatcher(otp6, null))

        // Handle backspace
        otp2.setOnKeyListener(BackspaceKeyListener(otp1))
        otp3.setOnKeyListener(BackspaceKeyListener(otp2))
        otp4.setOnKeyListener(BackspaceKeyListener(otp3))
        otp5.setOnKeyListener(BackspaceKeyListener(otp4))
        otp6.setOnKeyListener(BackspaceKeyListener(otp5))
    }

    private inner class OtpTextWatcher(
        private val currentView: EditText,
        private val nextView: EditText?
    ) : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun afterTextChanged(s: Editable?) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if (s?.length == 1) {
                nextView?.requestFocus()
            }

            // Auto submit when last box is filled
            if (currentView == otp6 && s?.length == 1) {
               // verifyOtp()
                hideKeyboard()
            }
        }
    }

    private inner class BackspaceKeyListener(
        private val previousView: EditText
    ) : View.OnKeyListener {
        override fun onKey(v: View?, keyCode: Int, event: KeyEvent?): Boolean {
            if (keyCode == KeyEvent.KEYCODE_DEL &&
                event?.action == KeyEvent.ACTION_DOWN &&
                (v as EditText).text.isEmpty()) {
                previousView.requestFocus()
                previousView.text.clear()
                return true
            }
            return false
        }
    }

    private fun handleIncomingOtp() {
        intent?.getStringExtra("txtPhno")?.let { txtData ->
            txtPhno.text = "+91 "+txtData+" to number"

        }
        intent?.getStringExtra("otp")?.let { otp ->
            if (otp.length == 6 && otp.all { it.isDigit() }) {
                otp1.setText(otp[0].toString())
                otp2.setText(otp[1].toString())
                otp3.setText(otp[2].toString())
                otp4.setText(otp[3].toString())
                otp5.setText(otp[4].toString())
                otp6.setText(otp[5].toString())
                otp6.requestFocus()
            }
        }
    }

    private fun verifyOtp() {
        val otp = "${otp1.text}${otp2.text}${otp3.text}${otp4.text}${otp5.text}${otp6.text}"
        val deviceId = Build.MODEL
        Toast.makeText(this, "Verifying OTP: $otp", Toast.LENGTH_SHORT).show()

        val phone = intent.getStringExtra("txtPhno") ?: ""

        if (otp.toString().length != 6) {
            Toast.makeText(this, "Please enter complete OTP", Toast.LENGTH_SHORT).show()
            return
        }
        viewModel.verifyOtp(phone, otp.toInt(), deviceId)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(otp6.windowToken, 0)
    }

    private fun setupObservers(sharedPreferencesHelper: SharedPreferencesHelper) {
        lifecycleScope.launchWhenStarted {
            viewModel.otpVerificationState.collectLatest { result ->
                when (result) {
                    is ApiResult.Loading -> showProgress()
                    is ApiResult.Success -> handleSuccess(result.data,sharedPreferencesHelper)
                    is ApiResult.Error -> handleError(result.message)
                    null -> Unit
                }
            }
        }
    }


    private fun handleSuccess(response: VerifyOtpResponse,sharedPreferencesHelper: SharedPreferencesHelper) {
        hideProgress()
        if (response.responseCode == 200) {
            sharedPreferencesHelper.storeLoginResponse(response)
            val intent = Intent(this, HomeCategoryActivity::class.java)
            startActivity(intent)
        } else {
            showError(response.message)
        }
    }

    private fun handleError(message: String) {
        hideProgress()
        showError(message)
    }

    private fun showProgress() {

    }

    private fun hideProgress() {

    }

    private fun showError(message: String) {

    }
}