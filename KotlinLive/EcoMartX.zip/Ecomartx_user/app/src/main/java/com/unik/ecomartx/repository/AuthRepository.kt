package com.unik.ecomartx.repository

import com.mindcoin.dservicevp.apis.ApiService
import com.unik.ecomartx.ApiResult
import com.unik.ecomartx.model.MobileCategories
import com.unik.ecomartx.model.NearbyRestaurants.GetRestaurentsById
import com.unik.ecomartx.model.NearbyRestaurants.MenuItemApiResponse
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsRequest
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsResponse
import com.unik.ecomartx.model.addToCart.AddToCartRequest
import com.unik.ecomartx.model.addToCart.AddToCartResponse
import com.unik.ecomartx.model.address.AddAddressRequest
import com.unik.ecomartx.model.address.AddAddressResponse
import com.unik.ecomartx.model.getUserProfile.UserProfileResponse
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartRequest
import com.unik.ecomartx.model.removeProductFromCart.RemoveProductFromCartResponse
import com.unik.ecomartx.model.userRegister.userRegisterRequest
import com.unik.ecomartx.model.userRegister.userRegisterResponse
import com.unik.ecomartx.model.verifyOtp.VerifyOtpRequest
import com.unik.ecomartx.model.verifyOtp.VerifyOtpResponse
import com.unik.ecomartx.modelimport.GetListOfCartItemsResponse
import retrofit2.Call

class AuthRepository {
    private val apiService = ApiService.api

    suspend fun verifyOtp(phone: String, otp: Int, deviceId: String): ApiResult<VerifyOtpResponse> {
        return try {
            val response = apiService.verifyOtp(VerifyOtpRequest(phone, otp, deviceId))

            if (response.isSuccessful) {
                response.body()?.let {
                    if (it.responseCode == 200) {
                        ApiResult.Success(it)
                    } else {
                        ApiResult.Error(it.message)
                    }
                } ?: ApiResult.Error("Empty response body")
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                ApiResult.Error("API error: ${response.code()} - $errorBody")
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Network request failed")
        }
    }

    suspend fun registerUser(
        authToken: String,
        request: userRegisterRequest
    ): ApiResult<userRegisterResponse> {
        return try {
            val response = apiService.registerUser(authToken, request)

            if (response.isSuccessful) {
                response.body()?.let {
                    if (it.responseCode == 200) {
                        ApiResult.Success(it)
                    } else {
                        ApiResult.Error(it.message)
                    }
                } ?: ApiResult.Error("Empty response body")
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                ApiResult.Error("API error: ${response.code()} - $errorBody")
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Network request failed")
        }
    }
    suspend fun addAddress(
        authToken: String,
        request: AddAddressRequest
    ): ApiResult<AddAddressResponse> {
        return try {
            val response = apiService.addAddress(authToken, request)

            if (response.isSuccessful) {
                response.body()?.let {
                    if (it.responseCode == 200) {
                        ApiResult.Success(it)
                    } else {
                        ApiResult.Error(it.message)
                    }
                } ?: ApiResult.Error("Empty response body")
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                ApiResult.Error("API error: ${response.code()} - $errorBody")
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Network request failed")
        }
    }


    suspend fun removeProductFromCart(
        authToken: String,
        request: RemoveProductFromCartRequest
    ): ApiResult<RemoveProductFromCartResponse> {
        return try {
            val response = apiService.removeProductFromCart(authToken, request)

            if (response.isSuccessful) {
                response.body()?.let {
                    if (it.responseCode == 200) {
                        ApiResult.Success(it)
                    } else {
                        ApiResult.Error(it.message)
                    }
                } ?: ApiResult.Error("Empty response body")
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                ApiResult.Error("API error: ${response.code()} - $errorBody")
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Network request failed")
        }
    }

    suspend fun getRestaurentItems(
        authToken: String,
        request: GetRestaurentsById
    ): ApiResult<MenuItemApiResponse> {
        return try {
            val response = apiService.getRestaurentItems(authToken, request)

            if (response.isSuccessful) {
                response.body()?.let {
                    if (it.responseCode == 200) {
                        ApiResult.Success(it)
                    } else {
                        ApiResult.Error(it.message)
                    }
                } ?: ApiResult.Error("Empty response body")
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                ApiResult.Error("API error: ${response.code()} - $errorBody")
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Network request failed")
        }
    }

     suspend fun getNearbyRestaurants(authToken: String, request: NearByRestaurentsRequest): ApiResult<NearByRestaurentsResponse> {
        return try {
            val response = apiService.getNearbyRestaurants(authToken,request)

            if (response.isSuccessful) {
                response.body()?.let {
                    if (it.responseCode == 200) {
                        ApiResult.Success(it)
                    } else {
                        ApiResult.Error(it.message)
                    }
                } ?: ApiResult.Error("Empty response body")
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                ApiResult.Error("API error: ${response.code()} - $errorBody")
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Network request failed")
        }
    }

    suspend fun addToCart(authToken: String, request: AddToCartRequest): ApiResult<AddToCartResponse> {
        return try {
            val response = apiService.addToCart(authToken,request)

            if (response.isSuccessful) {
                response.body()?.let {
                    if (it.responseCode == 200) {
                        ApiResult.Success(it)
                    } else {
                        ApiResult.Error(it.message)
                    }
                } ?: ApiResult.Error("Empty response body")
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                ApiResult.Error("API error: ${response.code()} - $errorBody")
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Network request failed")
        }
    }


    fun getUserDetails(authToken: String): Call<UserProfileResponse> {
        return apiService.getUserProfile("Bearer $authToken")
    }


    fun getMobileCategories(authToken: String): Call<MobileCategories> {
        return apiService.getMobileCategories("Bearer $authToken")
    }

    fun getListOfCartItems(authToken: String): Call<GetListOfCartItemsResponse> {
        return apiService.getListOfCartItems("Bearer $authToken")
    }


}