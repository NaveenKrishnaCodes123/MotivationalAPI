package com.unik.ecomartx

import com.unik.ecomartx.model.SortOption
import com.unik.ecomartx.model.SortType

fun SortOption.copy(
    label: String = this.label,
    type: SortType = this.type,
    isSelected: Boolean = this.isSelected
): SortOption {
    return SortOption(label, type, isSelected)
}