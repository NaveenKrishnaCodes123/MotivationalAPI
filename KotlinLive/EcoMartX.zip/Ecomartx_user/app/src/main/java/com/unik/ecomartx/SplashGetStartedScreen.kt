package com.unik.ecomartx

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SplashGetStartedScreen : AppCompatActivity() {
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_getstarted)
        val getStarted = findViewById<Button>(R.id.getStarted)
        /*getStarted.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }*/
        goToNextScreen()

    }

    private fun goToNextScreen() {
        sharedPreferencesHelper = SharedPreferencesHelper(this)
        GlobalScope.launch {
            delay(2000)  //
            withContext(Dispatchers.Main) {
                if (!sharedPreferencesHelper.isLoggedIn()) {
                    val intent = Intent(this@SplashGetStartedScreen, LoginWithMobileActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    val intent = Intent(this@SplashGetStartedScreen, HomeCategoryActivity::class.java)
                    startActivity(intent)
                    finish()
                }


            }
        }
    }

}