package com.unik.ecomartx.model.addToCart

data class AddToCartRequest(
    val item: String,
    val itemName: String,
    val price: Int,
    val purchaseQuantity: Int,
    val discount: Int = 0,
    val gst: Int = 0,
    val address: String
)
