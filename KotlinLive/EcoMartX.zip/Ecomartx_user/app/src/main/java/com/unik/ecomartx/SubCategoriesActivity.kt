package com.unik.ecomartx

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mindcoin.dservicevp.loader.ProgressBarUtility
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import com.unik.ecomartx.ApiResult
import com.unik.ecomartx.adapter.FoodItemsListAdapter
import com.unik.ecomartx.adapter.SubCategoryAdapter
import com.unik.ecomartx.model.NearbyRestaurants.GetRestaurentsById
import com.unik.ecomartx.model.NearbyRestaurants.MenuItemApiResponse
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsRequest
import com.unik.ecomartx.model.NearbyRestaurants.NearByRestaurentsResponse
import com.unik.ecomartx.repository.AuthRepository
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlin.getValue

class SubCategoriesActivity : AppCompatActivity() {
    private val viewModel: ViewModel by viewModels()
    private lateinit var ivBack: ImageView
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper
    private lateinit var authToken: String
    private lateinit var categoryId: String
    private lateinit var categoryName: String
    private lateinit var currentLatitude: String
    private lateinit var currentLongitude: String
    private lateinit var tvTitle: TextView
    private lateinit var rvitems: RecyclerView
    private lateinit var restaurantAdapter: SubCategoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub_categories)

        ivBack = findViewById(R.id.ivBack)
        tvTitle = findViewById(R.id.tvTitle)
        categoryId = intent.getStringExtra("categoryId").toString()
        categoryName = intent.getStringExtra("categoryName").toString()
        currentLatitude = intent.getStringExtra("currentLatitude").toString()
        currentLongitude = intent.getStringExtra("currentLongitude").toString()
        sharedPreferencesHelper = SharedPreferencesHelper(this)
        val loginResponse = sharedPreferencesHelper.getLoginResponse()
        loginResponse?.let {
            val loginData = it.user
            if (loginData != null) {
                authToken = loginData.token ?: "N/A"
            }
        } ?: run {
            Toast.makeText(this, "Please Logout and Login Once.", Toast.LENGTH_SHORT).show()
        }
        ivBack.setOnClickListener {
            finish()
        }
        tvTitle.setText(categoryName)
        getNearByRestaurents()
        setupObservers()


    }

    /* private fun fetchSubCategories() {
         val repository = AuthRepository()
         viewModel = ViewModelProvider(this, GetRestaurentModelFactory(repository)).get(ViewModel.getRestaurentViewModel::class.java)
         val rvRestaurants = findViewById<RecyclerView>(R.id.rvitems)
         rvRestaurants.layoutManager = GridLayoutManager(this, 1)
         restaurantAdapter = SubCategoryAdapter(emptyList()){
                 restaurant,position ->
             val intent = Intent(this, RestaurantDetailActivity::class.java)
             intent.putExtra("restaurent_token",restaurant.token)
             startActivity(intent)
         }
         rvRestaurants.adapter = restaurantAdapter

         viewModel.restaurentData.observe(this) { restaurants ->
             ProgressBarUtility.dismissProgressDialog()
             restaurantAdapter.updateData(restaurants)
         }

         viewModel.isLoading.observe(this) { isLoading ->
             if (isLoading) ProgressBarUtility.showProgressDialog(this)
         }
         viewModel.error.observe(this) { errorMessage ->
             Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
         }
         viewModel.getRestaurentDetails(authToken)

     }*/


    private fun getNearByRestaurents() {
        val request = NearByRestaurentsRequest(
            longitude = "78.3868",
            latitude = "17.4474",
            /*longitude = currentLongitude,
            latitude = currentLatitude,*/
            categoryId = "68401a398bbb901b33730c15"
                    /*categoryId = categoryId*/
        )
        viewModel.getNearbyRestaurants(authToken, request)

    }

    private fun setupObservers() {
        lifecycleScope.launchWhenStarted {
            viewModel.getNearbyRestaurants.collectLatest { result ->
                when (result) {
                    is ApiResult.Loading -> showProgress(true)
                    is ApiResult.Success -> handleSuccess(result.data)
                    is ApiResult.Error -> handleError(result.message)
                    else -> {}
                }
            }
        }
    }

    private fun handleSuccess(response: NearByRestaurentsResponse) {
        showProgress(false)
        if (response.responseCode == 200) {
            rvitems = findViewById(R.id.rvitems)
            rvitems.layoutManager = LinearLayoutManager(this)

            // Initialize adapter with empty list
            restaurantAdapter = SubCategoryAdapter(emptyList()) { restaurant, position ->
                val intent = Intent(this, RestaurantDetailActivity::class.java)
                intent.putExtra("categoryId", categoryId)
                intent.putExtra("restaurantToken", restaurant.token)
                intent.putExtra("restaurantName", restaurant.name)
                startActivity(intent)
            }
            rvitems.adapter = restaurantAdapter
            restaurantAdapter.updateData(response.data)
        } else {
            Toast.makeText(this, response.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleError(message: String) {
        showProgress(false)
        Toast.makeText(this, "Error: $message", Toast.LENGTH_SHORT).show()
    }

    private fun showProgress(show: Boolean) {

    }


}