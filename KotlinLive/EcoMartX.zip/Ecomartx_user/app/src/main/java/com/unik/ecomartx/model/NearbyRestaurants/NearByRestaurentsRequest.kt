package com.unik.ecomartx.model.NearbyRestaurants

data class NearByRestaurentsRequest(
    val longitude: String,
    val latitude: String,
    val categoryId: String,
)