package com.unik.ecomartx.model

data class MobileCategories(
    val responseCode: Int,
    val message: String,
    val categories: List<Categories>,
)
data class Categories(
    val categoryId: String,
    val name: String,
    val categoryImage: List<String>,
    val description: String,
    val subcategoryCount: Int,
)
