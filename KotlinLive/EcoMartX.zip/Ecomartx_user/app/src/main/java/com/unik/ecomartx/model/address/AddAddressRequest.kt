package com.unik.ecomartx.model.address

data class AddAddressRequest(
    val area: String,
    val streetName: String,
    val landMark: String,
    val city: String,
    val pincode: String,
    val state: String,
    val country: String = "India",
    val addressType: String,
    val isDefault: Boolean,
    val location: Location,
    val name: String,
    val phone: String,
    val houseNo: String
) {
    data class Location(
        val type: String = "Point",
        val coordinates: DoubleArray
    ) {
        constructor(longitude: Double, latitude: Double) : this("Point", doubleArrayOf(longitude, latitude))

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as Location

            if (type != other.type) return false
            if (!coordinates.contentEquals(other.coordinates)) return false

            return true
        }

        override fun hashCode(): Int {
            var result = type.hashCode()
            result = 31 * result + coordinates.contentHashCode()
            return result
        }
    }
}