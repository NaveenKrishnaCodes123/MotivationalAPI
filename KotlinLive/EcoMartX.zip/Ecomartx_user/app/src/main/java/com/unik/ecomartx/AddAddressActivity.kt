package com.unik.ecomartx

import android.Manifest
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.switchmaterial.SwitchMaterial
import com.mindcoin.dservicevp.apis.ApiService
import com.mindcoin.dservicevp.storage.SharedPreferencesHelper
import com.unik.ecomartx.ApiResult
import com.unik.ecomartx.model.address.AddAddressRequest
import com.unik.ecomartx.model.address.AddAddressResponse
import com.unik.ecomartx.model.userRegister.userRegisterRequest
import com.unik.ecomartx.model.userRegister.userRegisterResponse
import com.unik.ecomartx.viewModel.ViewModel
import kotlinx.coroutines.flow.collectLatest
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.util.*

class AddAddressActivity : AppCompatActivity() {
    private val viewModel: ViewModel by viewModels()
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var etPincode: EditText
    private lateinit var etState: EditText
    private lateinit var etCity: EditText
    private lateinit var etArea: EditText
    private lateinit var etHouseNo: EditText
    private lateinit var etLandmark: EditText
    private lateinit var rgAddressType: RadioGroup
    private lateinit var switchDefault: SwitchMaterial
    private lateinit var progressBar: ProgressBar
    private lateinit var locationContainer: LinearLayout
    private lateinit var tvLocation: TextView
    private lateinit var apiService: ApiService
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var sharedPreferencesHelper: SharedPreferencesHelper
    private lateinit var authToken: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_address)

        // Initialize views
        initializeViews()
        //setupRetrofit()
        setupLocationServices()
        sharedPreferencesHelper = SharedPreferencesHelper(this)
        val loginResponse = sharedPreferencesHelper.getLoginResponse()
        loginResponse?.let {
            val loginData = it.user
            if (loginData != null) {
                authToken = loginData.token ?: "N/A"
            }
        } ?: run {
            Toast.makeText(this, "Please Logout and Login Once.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnFetchLocation).setOnClickListener { fetchLocationFromPincode() }
        findViewById<Button>(R.id.btnSaveAddress).setOnClickListener { saveAddress() }
        findViewById<TextView>(R.id.tvCurrentLocation).setOnClickListener { getCurrentLocation() }
        findViewById<ImageView>(R.id.ivBack).setOnClickListener { finish() }
    }

    private fun initializeViews() {
        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etPincode = findViewById(R.id.etPincode)
        etState = findViewById(R.id.etState)
        etCity = findViewById(R.id.etCity)
        etArea = findViewById(R.id.etArea)
        etHouseNo = findViewById(R.id.etHouseNo)
        etLandmark = findViewById(R.id.etLandmark)
        rgAddressType = findViewById(R.id.rgAddressType)
        switchDefault = findViewById(R.id.switchDefault)
        progressBar = findViewById(R.id.progressBar)
        locationContainer = findViewById(R.id.locationContainer)
        tvLocation = findViewById(R.id.tvLocation)
    }


    private fun setupLocationServices() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }

    private fun fetchLocationFromPincode() {
        val pincode = etPincode.text.toString().trim()
        if (pincode.length != 6) {
            etPincode.error = "Enter 6-digit pincode"
            return
        }

        //progressBar.visibility = View.VISIBLE

    }

    private fun getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                100
            )
            return
        }

        progressBar.visibility = View.VISIBLE
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                progressBar.visibility = View.GONE
                if (location != null) {
                    // Reverse geocode to get address
                    val geocoder = Geocoder(this, Locale.getDefault())
                    try {
                        val addresses = geocoder.getFromLocation(
                            location.latitude,
                            location.longitude,
                            1
                        )

                        if (addresses != null && addresses.isNotEmpty()) {
                            updateUIWithLocation(addresses[0])
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                } else {
                    Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun updateUIWithLocation(address: Address) {
        etHouseNo.setText(address.featureName ?: "")
        etArea.setText(address.thoroughfare ?: "")
        etLandmark.setText(address.subLocality ?: "")
        etCity.setText(address.locality ?: "")
        etState.setText(address.adminArea ?: "")
        etPincode.setText(address.postalCode ?: "")

        locationContainer.visibility = View.VISIBLE
        tvLocation.text = "${address.locality}, ${address.adminArea}"
    }

    private fun getAddressType(): String {
        return when (rgAddressType.checkedRadioButtonId) {
            R.id.rbHome -> "home"
            R.id.rbWork -> "work"
            else -> "other"
        }
    }

    private fun validateFields(): Boolean {
        var isValid = true

        if (etName.text.toString().trim().isEmpty()) {
            etName.error = "Name required"
            isValid = false
        }
        if (etPhone.text.toString().trim().length != 10) {
            etPhone.error = "Valid mobile required"
            isValid = false
        }
        if (etPincode.text.toString().trim().length != 6) {
            etPincode.error = "Valid pincode required"
            isValid = false
        }
        if (etState.text.toString().trim().isEmpty()) {
            etState.error = "State required"
            isValid = false
        }
        if (etCity.text.toString().trim().isEmpty()) {
            etCity.error = "City required"
            isValid = false
        }
        if (etArea.text.toString().trim().isEmpty()) {
            etArea.error = "Area required"
            isValid = false
        }
        if (etHouseNo.text.toString().trim().isEmpty()) {
            etHouseNo.error = "House details required"
            isValid = false
        }

        return isValid
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Location permission required", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun saveAddress() {
        if (!validateFields()) return

        // Create address object
        val address = AddAddressRequest(
            area = etArea.text.toString().trim(),
            streetName = etHouseNo.text.toString().trim(), // Using house no as street name
            landMark = etLandmark.text.toString().trim(),
            city = etCity.text.toString().trim(),
            pincode = etPincode.text.toString().trim(),
            state = etState.text.toString().trim(),
            country = "India",
            addressType = getAddressType(),
            isDefault = switchDefault.isChecked,
            location = AddAddressRequest.Location(0.0, 0.0), // Dummy coordinates
            name = etName.text.toString().trim(),
            phone = etPhone.text.toString().trim(),
            houseNo = etHouseNo.text.toString().trim()
        )
        val token = authToken

        viewModel.addAddress(token, address)
        setupObservers()

    }

    private fun setupObservers() {
        lifecycleScope.launchWhenStarted {
            viewModel.addAddressRequest.collectLatest { result ->
                when (result) {
                    is ApiResult.Loading -> showProgress(true)
                    is ApiResult.Success -> handleRegistrationSuccess(result.data)
                    is ApiResult.Error -> handleError(result.message)
                    null -> Unit
                }
            }
        }
    }

    private fun handleRegistrationSuccess(response: AddAddressResponse) {
        if (response.responseCode == 200) {
            showToast("Profile created successfully!")
            finish()
        } else {
            showError(response.message)
        }
    }

    private fun handleError(message: String) {
        showToast("Error: $message")
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showProgress(show: Boolean) {

    }

    private fun showError(message: String) {
        showToast("Error: $message")
    }
}