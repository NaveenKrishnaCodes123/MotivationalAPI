package com.mindcoin.dservicevp.Model

class CheckOutRequest (
    val checkInId: String,
    val checkOutTime: String
)