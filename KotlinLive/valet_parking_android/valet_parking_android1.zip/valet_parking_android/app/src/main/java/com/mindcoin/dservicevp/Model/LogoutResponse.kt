package com.mindcoin.dservicevp.Model

data class LogoutResponse(
    val mssg: String,
    val content: List<Any>,
    val status: Int
)
