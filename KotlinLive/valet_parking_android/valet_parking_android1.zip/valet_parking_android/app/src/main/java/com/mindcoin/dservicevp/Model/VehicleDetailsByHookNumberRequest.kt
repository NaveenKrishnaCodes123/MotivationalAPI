package com.mindcoin.dservicevp.Model

class VehicleDetailsByHookNumberRequest (
    val companyId:String,
    val vehicleNo: String,
    val hookNo: String
)